
# RequestHeaderAISCallback

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**isDirectPsu** | **kotlin.Boolean** | (true/false) Znacznik informujący czy request jest przesłany bezpośrednio przez PSU. Domyślna wartość to false. / Is request sent by PSU directly. false is default value. |  [optional]
**callbackURL** | **kotlin.String** | adres funkcji zwrotnej / callback URL |  [optional]
**apiKey** | **kotlin.String** | API key dla wywołania funkcji zwrotnej / callback API key |  [optional]



