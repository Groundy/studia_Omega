
# TransactionInfoTax

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payerInfo** | [**Payor**](Payor.md) |  | 
**formCode** | **kotlin.String** | Symbol formularza Urzędu Skarbowego lub Izby Celnej / Tax authority form symbol | 
**periodId** | **kotlin.String** | Numer okresu. Wymagany warunkowo - w zależności od wartości parametru formCode. / Period number. Required conditionally - depending on formCode parameter value. |  [optional]
**periodType** | **kotlin.String** | Typ okresu. Wymagany warunkowo - w zależności od wartości parametru formCode. / Period type. Required conditionally - depending on formCode parameter value. |  [optional]
**year** | **kotlin.Int** | Rok okresu. Wymagany warunkowo - w zależności od wartości parametru formCode. / Period year. Required conditionally - depending on formCode parameter value. |  [optional]
**obligationId** | **kotlin.String** | Identyfikator zobowiązania, z którego wynika należność podatku np. decyzja, tytuł wykonawczy, postanowienie / Obligation ID |  [optional]



