
# DeleteConsentRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requestHeader** | [**RequestHeaderWithoutToken**](RequestHeaderWithoutToken.md) |  | 
**consentId** | **kotlin.String** | Identyfikator zgody / Consent ID | 



