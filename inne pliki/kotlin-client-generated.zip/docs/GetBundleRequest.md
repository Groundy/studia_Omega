
# GetBundleRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requestHeader** | [**RequestHeader**](RequestHeader.md) |  | 
**bundleId** | **kotlin.String** | Identyfikator paczki przelewów. Wymagany warunkowo - jeśli TPP otrzymał ten identyfikator od ASPSP. / Bundle of payments identifier.Conditionally required - in case TPP has received this identifier from ASPSP. |  [optional]
**tppBundleId** | **kotlin.String** | Identyfikator paczki przelewów nadany przez TPP. Wymagany warunkowo - jeśli TPP nie otrzymał identyfikatora bundleId od ASPSP. / Bundle of payments identifier set by TPP. Conditionally required - in case TPP has not received bundleId from ASPSP. |  [optional]
**transactionsIncluded** | **kotlin.Boolean** | (true / false) Znacznik oznaczający czy w odpowiedzi mają być uwzględnione statusy transakcji wchodzące w skład paczki / Indicates if statuses of payments from the bundle should be included | 



