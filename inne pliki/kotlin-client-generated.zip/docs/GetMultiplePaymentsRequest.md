
# GetMultiplePaymentsRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requestHeader** | [**RequestHeaderWithoutToken**](RequestHeaderWithoutToken.md) |  | 
**payments** | [**kotlin.Array&lt;PaymentTokenEntry&gt;**](PaymentTokenEntry.md) |  | 



