
# TransactionScheduledInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transactionCategory** | [**inline**](#TransactionCategoryEnum) | Kategoria transakcji uznanie/obciążenie / Transaction category (credit/debit) | 
**transactionStatus** | [**DictionaryItem**](DictionaryItem.md) |  |  [optional]
**initiator** | [**NameAddress**](NameAddress.md) |  |  [optional]
**sender** | [**SenderRecipient**](SenderRecipient.md) |  |  [optional]
**recipient** | [**SenderRecipient**](SenderRecipient.md) |  |  [optional]


<a name="TransactionCategoryEnum"></a>
## Enum: transactionCategory
Name | Value
---- | -----
transactionCategory | CREDIT, DEBIT



