
# AccountBaseInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountNumber** | **kotlin.String** | Numer rachunku (częściowo zamaskowany) / Account number (partly masked) | 
**accountTypeName** | **kotlin.String** | Nazwa typu rachunku (definiowana przez ASPSP) / Account&#39;s type name (defined by ASPSP) | 
**accountType** | [**DictionaryItem**](DictionaryItem.md) |  | 
**psuRelations** | [**kotlin.Array&lt;AccountPsuRelation&gt;**](AccountPsuRelation.md) | Informacje na temat relacji PSU do rachunku / Description of relations between PSU and an Account | 



