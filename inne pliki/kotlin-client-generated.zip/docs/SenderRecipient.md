
# SenderRecipient

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountNumber** | **kotlin.String** | Numer konta nadawcy/odbiorcy / Account number |  [optional]
**accountMassPayment** | **kotlin.String** | Numer wirtualny rachunku odbiorcy w formacie / Virtual account name |  [optional]
**bank** | [**Bank**](Bank.md) |  |  [optional]
**nameAddress** | [**NameAddress**](NameAddress.md) |  |  [optional]



