
# DictionaryItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **kotlin.String** | Kod pozycji słownika / Code |  [optional]
**description** | **kotlin.String** | Opis pozycji słownika / Description |  [optional]



