
# RecurringTransferParameters

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**startDate** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) | Data wykonania pierwszej płatności w definiowanym cyklu. Format: YYYY-MM-DD / First payment execution date (of the defined cycle). | 
**frequency** | [**RecurringTransferFrequency**](RecurringTransferFrequency.md) |  | 
**endDate** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) | Ostatnia możliwa data wykonania płatności w definiowanym cyklu. Format: YYYY-MM-DD / The last possible payment execution date (of the defined cycle). |  [optional]
**dayOffOffsetType** | [**inline**](#DayOffOffsetTypeEnum) | Rodzaj przesunięcia, który należy zastosować do wykonania przelewu w przypadku, gdy dzień wolny jest planowaną datą przelewu / Type of offset that should be used for transfer execution in case of day off being the planned date of transfer | 


<a name="DayOffOffsetTypeEnum"></a>
## Enum: dayOffOffsetType
Name | Value
---- | -----
dayOffOffsetType | before, after



