
# TransactionRejectedInfoResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**responseHeader** | [**ResponseHeader**](ResponseHeader.md) |  | 
**transactions** | [**kotlin.Array&lt;TransactionRejectedInfo&gt;**](TransactionRejectedInfo.md) |  |  [optional]
**pageInfo** | [**PageInfo**](PageInfo.md) |  |  [optional]



