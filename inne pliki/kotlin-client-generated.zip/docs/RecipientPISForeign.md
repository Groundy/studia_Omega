
# RecipientPISForeign

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**countryCode** | **kotlin.String** | Kod kraju odbiorcy przelewu, wg normy ISO 3166-1 alfa-3 / Country code of payment recipient, ISO 3166-1 alfa-3 compliant | 



