
# SocialSecurityPayor

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nip** | **kotlin.String** | Numer Identyfikacji Podatkowej / Payor&#39;s Tax Identification Number |  [optional]
**additionalPayorId** | **kotlin.String** | Dodatkowy numer identyfikacyjny płatnika / Payor&#39;s additional identification number |  [optional]
**additionalPayorIdType** | [**inline**](#AdditionalPayorIdTypeEnum) | Typ dodatkowego identyfikatora płatnika / Payor&#39;s additional identifier type |  [optional]


<a name="AdditionalPayorIdTypeEnum"></a>
## Enum: additionalPayorIdType
Name | Value
---- | -----
additionalPayorIdType | P, R, 1, 2



