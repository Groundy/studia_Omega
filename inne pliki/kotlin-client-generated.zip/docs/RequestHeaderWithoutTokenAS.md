
# RequestHeaderWithoutTokenAS

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**isCompanyContext** | **kotlin.Boolean** | (true / false) Znacznik oznaczający czy żądanie jest wysyłane w kontekście PSU korporacyjnego |  [optional]
**psuIdentifierType** | **kotlin.String** | Typ identyfikatora PSU, służy do wskazania przez TPP na podstawie jakiej informacji zostanie zidentyfikowany PSU, który będzie podlegał uwierzytelnieniu. Wartość słownikowa. / PSU identifier type, used by TPP to indicate type of information based on which the PSU is to be authenticated. Dictionary value. |  [optional]
**psuIdentifierValue** | **kotlin.String** | Wartość identyfikatora PSU. Wymagany warunkowo - w przypadku gdy została przekazana niepusta wartość typu identyfikatora PSU. / The value of the PSU&#39;s identifier. Required conditionally - in case non empty value of PSU identifier type was passed. |  [optional]
**psuContextIdentifierType** | **kotlin.String** | Typ identyfikatora kontekstu w jakim występuje PSU. Wartość słownikowa. Wymagany warunkowo - w przypadku wysyłania żądania dla takiego PSU, który może występować w więcej niż jednym kontekście w wybranym ASPSP. / Identifier of context that is used by PSU. Dictionary value. Required conditionally - in case context of the request is used and PSU may use more then one context for the ASPSP. |  [optional]
**psuContextIdentifierValue** | **kotlin.String** | Wartość identyfikatora kontekstu w jakim występuje PSU. Wymagany warunkowo - w przypadku wysyłania żądania dla takiego PSU, który może występować w więcej niż jednym kontekście w wybranym ASPSP. / The value of context that is used by PSU. Required conditionally - in case context of the request is used and PSU may use more then one context for the ASPSP. |  [optional]



