
# TransactionInfoSp

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**spInvoiceNumber** | **kotlin.String** | Numer faktury / Invoice number | 
**spTaxIdentificationNumber** | **kotlin.String** | Identyfikator odbiorcy, np. numer NIP / Payment recipient identifier i.e. Tax Identification Number | 
**spTaxAmount** | **kotlin.String** | Kwota podatku VAT / Amount of VAT | 
**spDescription** | **kotlin.String** | Opis dodatkowy / Additional description |  [optional]



