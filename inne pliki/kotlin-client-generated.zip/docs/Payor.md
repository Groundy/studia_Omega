
# Payor

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payorId** | **kotlin.String** | Identyfikator płatnika / Payor ID | 
**payorIdType** | [**inline**](#PayorIdTypeEnum) | Typ identyfikatora płatnika / Payor ID type | 


<a name="PayorIdTypeEnum"></a>
## Enum: payorIdType
Name | Value
---- | -----
payorIdType | N, P, R, 1, 2, 3



