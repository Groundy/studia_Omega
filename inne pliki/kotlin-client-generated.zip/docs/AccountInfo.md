
# AccountInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountNumber** | **kotlin.String** | Numer rachunku / Account number | 
**nameAddress** | [**NameAddress**](NameAddress.md) |  | 
**accountType** | [**DictionaryItem**](DictionaryItem.md) |  | 
**accountTypeName** | **kotlin.String** | Nazwa typu rachunku (definiowana przez ASPSP) / Account&#39;s type name (defined by ASPSP) |  [optional]
**accountHolderType** | [**inline**](#AccountHolderTypeEnum) | Rodzaj posiadacza rachunku: osoba fizyczna lub osoba prawna / Account holder type: individual person or corporation | 
**accountNameClient** | **kotlin.String** | Nazwa konta ustawiona przez klienta / Account name set by the client |  [optional]
**currency** | **kotlin.String** | Waluta rachunku / Currency | 
**availableBalance** | **kotlin.String** | Dostępne środki - po wykonaniu transakcji / Available funds | 
**bookingBalance** | **kotlin.String** | Saldo księgowe rachunku - po wykonaniu transakcji / Book balance of the account | 
**bank** | [**BankAccountInfo**](BankAccountInfo.md) |  |  [optional]
**psuRelations** | [**kotlin.Array&lt;AccountPsuRelation&gt;**](AccountPsuRelation.md) | Informacje na temat relacji PSU do rachunku / Description of relations between PSU and an Account | 
**vatAccountNrb** | **kotlin.String** | Numer rachunku VAT / VAT account number |  [optional]
**linkedAccountNumber** | **kotlin.Array&lt;kotlin.String&gt;** | Lista numerów rachunkuów powiązanych z rachunkiem VAT / Account numbers list related to VAT account |  [optional]
**auxData** | [**Map**](Map.md) |  |  [optional]


<a name="AccountHolderTypeEnum"></a>
## Enum: accountHolderType
Name | Value
---- | -----
accountHolderType | individual, corporation



