
# AuthorizeRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requestHeader** | [**RequestHeaderWithoutTokenAS**](RequestHeaderWithoutTokenAS.md) |  | 
**response_type** | **kotlin.String** | Typ odpowiedzi. Wartość stała: code / Type of response. Fixed value: code | 
**client_id** | **kotlin.String** | Identyfikator TPP / TPP ID | 
**redirect_uri** | **kotlin.String** | Adres usługi TPP, na które zostanie wykonane przekierowanie po uwierzytelnieniu klienta ASPSP / The Address of the TPP service to which the redirection will be performed after ASPSP client authentication | 
**scope** | **kotlin.String** | Typ zgody, o którą prosi TPP. Wybrana wartość z listy dostępnych identyfikatorów zgód, opisanych w specyfikacji standardu Polish API. / Type of consent requested by the TPP. The value that is selected from the list of available consent identifiers, described in the Polish API specification. | 
**scope_details** | [**ScopeDetailsInput**](ScopeDetailsInput.md) |  | 
**state** | **kotlin.String** | Losowa, unikalna w ramach TPP wartość – zabezpieczenie przed atakiem Cross-Site Request Forgery / Random, unique value within TPP - protection against Cross-Site Request Forgery attack | 



