
# PrivilegeRecurringPayment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**scopeUsageLimit** | [**inline**](#ScopeUsageLimitEnum) | Rodzaj limitu zgody / Type of limit of usages |  [optional]
**recurrence** | [**RecurringTransferParameters**](RecurringTransferParameters.md) |  |  [optional]
**typeOfPayment** | [**inline**](#TypeOfPaymentEnum) | Typ przelewu, który zostanie wykorzystany do zdefiniowania nowej płatności cyklicznej  / The type of payment that is to be used to define new recurring payment |  [optional]
**domesticPayment** | [**RecurringDomesticPayment**](RecurringDomesticPayment.md) |  |  [optional]
**EEAPayment** | [**RecurringEEAPayment**](RecurringEEAPayment.md) |  |  [optional]
**nonEEAPayment** | [**RecurringNonEEAPayment**](RecurringNonEEAPayment.md) |  |  [optional]
**taxPayment** | [**RecurringTaxPayment**](RecurringTaxPayment.md) |  |  [optional]


<a name="ScopeUsageLimitEnum"></a>
## Enum: scopeUsageLimit
Name | Value
---- | -----
scopeUsageLimit | single, multiple


<a name="TypeOfPaymentEnum"></a>
## Enum: typeOfPayment
Name | Value
---- | -----
typeOfPayment | domestic, EEA, nonEEA, tax



