
# RequestHeader

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token** | **kotlin.String** | Token autoryzacyjny / Authorization token | 



