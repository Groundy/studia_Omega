
# RegisterJWKSKeys

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**kty** | **kotlin.String** |  | 
**x5c** | **kotlin.Array&lt;kotlin.String&gt;** |  | 
**use** | **kotlin.String** |  | 
**kid** | **kotlin.String** |  | 



