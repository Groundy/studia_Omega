
# TransactionRejectedInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transactionCategory** | [**inline**](#TransactionCategoryEnum) | Kategoria transakcji uznanie/obciążenie / Transaction category (credit/debit) | 
**initiator** | [**NameAddress**](NameAddress.md) |  |  [optional]
**sender** | [**SenderRecipient**](SenderRecipient.md) |  |  [optional]
**recipient** | [**SenderRecipient**](SenderRecipient.md) |  |  [optional]
**rejectionReason** | **kotlin.String** | Powod odrzucenia |  [optional]
**rejectionDate** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) | Data odrzucenia, YYYY-MM-DDThh:mm:ss[.mmm] / Rejection date |  [optional]


<a name="TransactionCategoryEnum"></a>
## Enum: transactionCategory
Name | Value
---- | -----
transactionCategory | CREDIT, DEBIT



