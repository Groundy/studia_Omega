
# ItemInfoBase

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**itemId** | **kotlin.String** | ID elementu (transakcji lub blokadzie) nadany przez ASPSP / Element (transaction or hold) ID (ASPSP) | 
**amount** | **kotlin.String** | Kwota transakcji / Amount of the transaction | 
**currency** | **kotlin.String** | Kod ISO waluty transakcji / Currency (ISO) |  [optional]
**description** | **kotlin.String** | Tytuł transakcji / Description of the transaction |  [optional]
**transactionType** | **kotlin.String** | Typ transakcji / Transaction type |  [optional]
**tradeDate** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) | Data operacji, YYYY-MM-DDThh:mm:ss[.mmm] / Date of the operation |  [optional]
**mcc** | **kotlin.String** | Kod dla każdej transakcji/operacji wykonanej przy użyciu karty / A code of each transaction performed by card |  [optional]
**auxData** | [**Map**](Map.md) |  |  [optional]



