
# TransferDataCurrencyRequiredTax

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currency** | **kotlin.String** | Waluta, wymagana wartość PLN / Currency - PLN value required | 



