
# ScopeDetailsOutputPrivilegeList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountNumber** | [**AccountNumber**](AccountNumber.md) |  |  [optional]
**ais-accounts:getAccounts** | [**PrivilegeAisAspspOutSimple**](PrivilegeAisAspspOutSimple.md) |  |  [optional]
**ais:getAccount** | [**PrivilegeAisAspspOutSimple**](PrivilegeAisAspspOutSimple.md) |  |  [optional]
**ais:getHolds** | [**PrivilegeAisAspspOut**](PrivilegeAisAspspOut.md) |  |  [optional]
**ais:getTransactionsDone** | [**PrivilegeAisAspspOut**](PrivilegeAisAspspOut.md) |  |  [optional]
**ais:getTransactionsPending** | [**PrivilegeAisAspspOut**](PrivilegeAisAspspOut.md) |  |  [optional]
**ais:getTransactionsRejected** | [**PrivilegeAisAspspOut**](PrivilegeAisAspspOut.md) |  |  [optional]
**ais:getTransactionsCancelled** | [**PrivilegeAisAspspOut**](PrivilegeAisAspspOut.md) |  |  [optional]
**ais:getTransactionsScheduled** | [**PrivilegeAisAspspOut**](PrivilegeAisAspspOut.md) |  |  [optional]
**ais:getTransactionDetail** | [**PrivilegeAisAspspOutSimple**](PrivilegeAisAspspOutSimple.md) |  |  [optional]
**pis:getPayment** | [**PrivilegePayment**](PrivilegePayment.md) |  |  [optional]
**pis:getBundle** | [**PrivilegeBundle**](PrivilegeBundle.md) |  |  [optional]
**pis:domestic** | [**PrivilegeDomesticTransfer**](PrivilegeDomesticTransfer.md) |  |  [optional]
**pis:EEA** | [**PrivilegeForeignTransferEEA**](PrivilegeForeignTransferEEA.md) |  |  [optional]
**pis:nonEEA** | [**PrivilegeForeignTransferNonEEA**](PrivilegeForeignTransferNonEEA.md) |  |  [optional]
**pis:tax** | [**PrivilegeTaxTransfer**](PrivilegeTaxTransfer.md) |  |  [optional]
**pis:cancelPayment** | [**PrivilegeCancelPayment**](PrivilegeCancelPayment.md) |  |  [optional]
**pis:bundle** | [**PrivilegeBundleTransfers**](PrivilegeBundleTransfers.md) |  |  [optional]
**pis:recurring** | [**PrivilegeRecurringPayment**](PrivilegeRecurringPayment.md) |  |  [optional]
**pis:getRecurringPayment** | [**PrivilegeRecurringPaymentStatus**](PrivilegeRecurringPaymentStatus.md) |  |  [optional]
**pis:cancelRecurringPayment** | [**PrivilegeCancelRecurringPayment**](PrivilegeCancelRecurringPayment.md) |  |  [optional]



