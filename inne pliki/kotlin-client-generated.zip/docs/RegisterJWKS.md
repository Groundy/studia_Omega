
# RegisterJWKS

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**keys** | [**kotlin.Array&lt;RegisterJWKSKeys&gt;**](RegisterJWKSKeys.md) |  | 



