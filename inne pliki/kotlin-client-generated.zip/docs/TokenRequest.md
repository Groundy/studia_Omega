
# TokenRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requestHeader** | [**RequestHeaderToken**](RequestHeaderToken.md) |  |  [optional]
**grant_type** | **kotlin.String** | Typ zastosowanej autoryzacji. Jedna z wartości: authorization_code, refresh_token, exchange_token (rozszerzenie standardu OAuth2) / Type of authorization used. One of the following values: authorization_code, refresh_token, exchange_token (extension of OAuth2 standard) | 
**Code** | **kotlin.String** | Kod autoryzacji uzyskany podczas żądania do usługi /authorize OAuth2. Wymagany dla grant_type&#x3D;authorization_code. / An authorization code obtained when requesting the /authorize OAuth2 service. Required for grant_type&#x3D;authorization_code. |  [optional]
**redirect_uri** | **kotlin.String** | Adres usługi TPP, na które zostanie wykonane przekierowanie po wygenerowaniu tokena dostępowego przez ASPSP. Wymagany dla grant_type&#x3D;authorization_code. / The address of the TPP service to which the redirection will be performed after the ASPSP generates the access token. Required for grant_type&#x3D;authorization_code. |  [optional]
**client_id** | **kotlin.String** | Identyfikator TPP. Wymagany dla grant_type&#x3D;authorization_code. / TPP ID. Required for grant_type&#x3D;authorization_code. |  [optional]
**refresh_token** | **kotlin.String** | Wartość tokena, który służy do uzyskania nowego tokena dostępowego dla tego samego zakresu zgód (scope, scope_details) - w przypadku gdy pierwotny token utraci swoją ważność, lub dla zawężonego zakresu zgód. Wymagany dla grant_type&#x3D;refresh_token. / Value of the token used to obtain a new access token for the same scope of consents (scope, scope_details) - in case the original token expires or for a narrower scope of consents. Required for grant_type&#x3D;refresh_token. |  [optional]
**exchange_token** | **kotlin.String** | Wartość tokena, który służy do uzyskania nowego tokena dostępowego dla innego zakresu zgód (scope, scope_details). Wartością tego parametru powinien być token dostępowy ważnej sesji komuikacyjnej z interfejsem XS2A. Wymagany dla grant_type&#x3D;exchange_token. / Value of the token, which is used to obtain a new access token for a different scope of consents (scope, scope_details). The value of this parameter should be the access token of a valid communication session with the XS2A interface. Required for grant_type&#x3D;exchange_token. |  [optional]
**scope** | **kotlin.String** | Typ zgody, o którą prosi TPP. Wybrana wartość z listy dostępnych identyfikatorów zgód, opisanych w specyfikacji standardu Polish API. Wymagany dla grant_type&#x3D;exchange_token. / Type of consent requested by the TPP. The value selected from the list of available consent identifiers, described in the Polish API specification. Required for grant_type&#x3D;exchange_token. |  [optional]
**scope_details** | [**ScopeDetailsInput**](ScopeDetailsInput.md) |  |  [optional]
**is_user_session** | **kotlin.Boolean** | Określa czy dana sesja jest związana z interakcją z PSU – wartości true/false. Rozszerzenie standardu OAuth2. / Defines whether the session is related to the PSU interaction - true/false values. Extension of the OAuth2 standard. |  [optional]
**user_ip** | **kotlin.String** | IP przeglądarki użytkownika (informacja na potrzeby fraud detection). Rozszerzenie standardu OAuth2. Wymagany dla is_user_session &#x3D; true. / User&#39;s browser IP (information for fraud detection). Extension of the OAuth2 standard. Required for is_user_session &#x3D; true. |  [optional]
**user_agent** | **kotlin.String** | Informacja dotycząca wersji przeglądarki użytkownika (informacja na potrzeby fraud detection). Rozszerzenie standardu OAuth2. Wymagany dla is_user_session &#x3D; true. / Information about the version of the user&#39;s browser (information for fraud detection). Extension of the OAuth2 standard. Required for is_user_session &#x3D; true. |  [optional]



