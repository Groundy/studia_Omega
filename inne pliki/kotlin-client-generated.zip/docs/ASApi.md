# ASApi

All URIs are relative to *https://apiHost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**authorize**](ASApi.md#authorize) | **POST** /v3_0.1/auth/v3_0.1/authorize | Żądanie kodu autoryzacji OAuth2 / Requests OAuth2 authorization code
[**authorizeExt**](ASApi.md#authorizeExt) | **POST** /v3_0.1/auth/v3_0.1/authorizeExt | Żądanie wydania kodu autoryzacji OAuth2 na podstawie jednorazowego kodu autoryzacji wydanego przez narzędzie autoryzacji zewnętrznej / Requests OAuth2 authorization code based on One-time authorization code issued by External Authorization Tool
[**register**](ASApi.md#register) | **POST** /v3_0.1/auth/v3_0.1/register | Żądanie rejestracji aplikacji klienckiej / Client application registration request
[**token**](ASApi.md#token) | **POST** /v3_0.1/auth/v3_0.1/token | Żądanie wydania tokena dostępu OAuth2 / Requests OAuth2 access token value


<a name="authorize"></a>
# **authorize**
> AuthorizeResponse authorize(acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, authorizeRequest)

Żądanie kodu autoryzacji OAuth2 / Requests OAuth2 authorization code

Żądanie kodu autoryzacji OAuth2 / Requests OAuth2 authorization code

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = ASApi()
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val authorizeRequest : AuthorizeRequest =  // AuthorizeRequest | Dane do zapytania o kod autoryzacyjny OAuth2 / Data for OAuth2 Authorization Code Request
try {
    val result : AuthorizeResponse = apiInstance.authorize(acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, authorizeRequest)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ASApi#authorize")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ASApi#authorize")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **authorizeRequest** | [**AuthorizeRequest**](AuthorizeRequest.md)| Dane do zapytania o kod autoryzacyjny OAuth2 / Data for OAuth2 Authorization Code Request |

### Return type

[**AuthorizeResponse**](AuthorizeResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="authorizeExt"></a>
# **authorizeExt**
> authorizeExt(acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, eatCodeRequest)

Żądanie wydania kodu autoryzacji OAuth2 na podstawie jednorazowego kodu autoryzacji wydanego przez narzędzie autoryzacji zewnętrznej / Requests OAuth2 authorization code based on One-time authorization code issued by External Authorization Tool

Żądanie wydania kodu autoryzacji OAuth2 na podstawie jednorazowego kodu autoryzacji wydanego przez narzędzie autoryzacji zewnętrznej. Kod autoryzacji zostanie dostarczony do TPP jako zapytanie zwrotne z ASPSP, jeśli uwierzytelnienie PSU zostanie potwierdzone przez EAT. Funkcja zwrotna musi zapewniać podobne powiadomienie również w przypadku nieudanego uwierzytelnienia lub jego rezygnacji. / Requests OAuth2 authorization code based One-time authorization code issued by External Authorization Tool. Authorization code will be delivered to TPP as callback request from ASPSP if PSU authentication is confirmed by EAT. Callback function must provide similar notification also in case of unsuccessful authentication or its abandonment.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = ASApi()
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val eatCodeRequest : EatCodeRequest =  // EatCodeRequest | Dane dla zapytania o kod autoryzacji OAuth2 rozszerzone dla uwierzytelniania opartego na EAT i odpowiedzi zwrotnej / Data for OAuth2 Authorization Code Request extended for EAT based authentication and callback response
try {
    apiInstance.authorizeExt(acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, eatCodeRequest)
} catch (e: ClientException) {
    println("4xx response calling ASApi#authorizeExt")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ASApi#authorizeExt")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **eatCodeRequest** | [**EatCodeRequest**](EatCodeRequest.md)| Dane dla zapytania o kod autoryzacji OAuth2 rozszerzone dla uwierzytelniania opartego na EAT i odpowiedzi zwrotnej / Data for OAuth2 Authorization Code Request extended for EAT based authentication and callback response |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="register"></a>
# **register**
> RegisterResponse register(acceptEncoding, acceptLanguage, acceptCharset, xREQUESTID, registerRequest)

Żądanie rejestracji aplikacji klienckiej / Client application registration request

Żądanie rejestracji aplikacji klienckiej / Client application registration request

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = ASApi()
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val registerRequest : RegisterRequest =  // RegisterRequest | Dane żądania rejestracji aplikacji klienckiej / Client application registration request data
try {
    val result : RegisterResponse = apiInstance.register(acceptEncoding, acceptLanguage, acceptCharset, xREQUESTID, registerRequest)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ASApi#register")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ASApi#register")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **registerRequest** | [**RegisterRequest**](RegisterRequest.md)| Dane żądania rejestracji aplikacji klienckiej / Client application registration request data |

### Return type

[**RegisterResponse**](RegisterResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="token"></a>
# **token**
> TokenResponse token(acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, tokenRequest)

Żądanie wydania tokena dostępu OAuth2 / Requests OAuth2 access token value

Żądanie wydania tokena dostępu OAuth2 / Requests OAuth2 access token value

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = ASApi()
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val tokenRequest : TokenRequest =  // TokenRequest | Dane żądania o wydanie tokena dostępu OAuth2 / Data for OAuth2 Access Token Request
try {
    val result : TokenResponse = apiInstance.token(acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, tokenRequest)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ASApi#token")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ASApi#token")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **tokenRequest** | [**TokenRequest**](TokenRequest.md)| Dane żądania o wydanie tokena dostępu OAuth2 / Data for OAuth2 Access Token Request |

### Return type

[**TokenResponse**](TokenResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

