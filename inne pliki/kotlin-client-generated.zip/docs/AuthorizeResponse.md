
# AuthorizeResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**responseHeader** | [**ResponseHeader**](ResponseHeader.md) |  | 
**aspspRedirectUri** | **kotlin.String** | Adres po stronie ASPSP, na który TPP powinien dokonać przekierowania przeglądarki PSU w celu jego uwierzytelnienia / The address on the ASPSP side to which the TPP should redirect the PSU browser in order to authenticate PSU | 



