
# RequestHeaderWithoutTokenCallbackAS

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**callbackURL** | **kotlin.String** | adres funkcji zwrotnej / callback URL |  [optional]
**apiKey** | **kotlin.String** | API key dla wywołania funkcji zwrotnej / callback API key |  [optional]



