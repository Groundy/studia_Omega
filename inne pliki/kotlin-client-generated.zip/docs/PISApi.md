# PISApi

All URIs are relative to *https://apiHost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**bundle**](PISApi.md#bundle) | **POST** /v3_0.1/payments/v3_0.1/bundle | Inicjacja wielu przelewów / Initiate many transfers as bundle
[**cancelPayments**](PISApi.md#cancelPayments) | **POST** /v3_0.1/payments/v3_0.1/cancelPayments | Anulowanie zaplanowanych płatności / Cancelation of future dated payment
[**cancelRecurringPayment**](PISApi.md#cancelRecurringPayment) | **POST** /v3_0.1/payments/v3_0.1/cancelRecurringPayment | Anulowanie płatności cyklicznej / Cancelation of recurring payment
[**domestic**](PISApi.md#domestic) | **POST** /v3_0.1/payments/v3_0.1/domestic | Inicjacja przelewu krajowego / Initiate domestic transfer
[**eEA**](PISApi.md#eEA) | **POST** /v3_0.1/payments/v3_0.1/EEA | Inicjacja przelewów zagranicznych SEPA / Initiate SEPA foreign transfers
[**getBundle**](PISApi.md#getBundle) | **POST** /v3_0.1/payments/v3_0.1/getBundle | Uzyskanie status paczki przelewów / Get the status of bundle of payments
[**getMultiplePayments**](PISApi.md#getMultiplePayments) | **POST** /v3_0.1/payments/v3_0.1/getMultiplePayments | Uzyskanie statusu wielu płatności / Get the status of multiple payments
[**getPayment**](PISApi.md#getPayment) | **POST** /v3_0.1/payments/v3_0.1/getPayment | Uzyskanie statusu płatności / Get the status of payment
[**getRecurringPayment**](PISApi.md#getRecurringPayment) | **POST** /v3_0.1/payments/v3_0.1/getRecurringPayment | Uzyskanie status płatności cyklicznej / Get the status of recurring payment
[**nonEEA**](PISApi.md#nonEEA) | **POST** /v3_0.1/payments/v3_0.1/nonEEA | Inicjacja przelewów zagranicznych niezgodnych z SEPA / Initiate non SEPA foreign transfers
[**recurring**](PISApi.md#recurring) | **POST** /v3_0.1/payments/v3_0.1/recurring | Definicja nowej płatności cyklicznej / Defines new recurring payment
[**tax**](PISApi.md#tax) | **POST** /v3_0.1/payments/v3_0.1/tax | Inicjacja przelewu do organu podatkowego / Initiate tax transfer


<a name="bundle"></a>
# **bundle**
> BundleResponse bundle(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, bundleRequest)

Inicjacja wielu przelewów / Initiate many transfers as bundle



### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = PISApi()
val authorization : kotlin.String = authorization_example // kotlin.String | Wartość nagłówka 'Authorization' powinna składać się z 'type' + 'credentials', gdzie dla metody z użyciem 'type', token powinien być typu 'Bearer'. / The value of the Authorization header should consist of 'type' + 'credentials', where for the approach using the 'type' token should be 'Bearer'.
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val bundleRequest : BundleRequest =  // BundleRequest | Dane żądania inicjalizacji wielu przelewów / Data for bundle of transfers
try {
    val result : BundleResponse = apiInstance.bundle(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, bundleRequest)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling PISApi#bundle")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling PISApi#bundle")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **kotlin.String**| Wartość nagłówka &#39;Authorization&#39; powinna składać się z &#39;type&#39; + &#39;credentials&#39;, gdzie dla metody z użyciem &#39;type&#39;, token powinien być typu &#39;Bearer&#39;. / The value of the Authorization header should consist of &#39;type&#39; + &#39;credentials&#39;, where for the approach using the &#39;type&#39; token should be &#39;Bearer&#39;. |
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **bundleRequest** | [**BundleRequest**](BundleRequest.md)| Dane żądania inicjalizacji wielu przelewów / Data for bundle of transfers |

### Return type

[**BundleResponse**](BundleResponse.md)

### Authorization

[xs2a_auth_aspsp](../README.md#xs2a_auth_aspsp), [xs2a_auth_decoupled](../README.md#xs2a_auth_decoupled)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="cancelPayments"></a>
# **cancelPayments**
> CancelPaymentsResponse cancelPayments(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, payment data)

Anulowanie zaplanowanych płatności / Cancelation of future dated payment

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = PISApi()
val authorization : kotlin.String = authorization_example // kotlin.String | Wartość nagłówka 'Authorization' powinna składać się z 'type' + 'credentials', gdzie dla metody z użyciem 'type', token powinien być typu 'Bearer'. / The value of the Authorization header should consist of 'type' + 'credentials', where for the approach using the 'type' token should be 'Bearer'.
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val payment data : CancelPaymentsRequest =  // CancelPaymentsRequest | Płatności do anulowania - dane identyfikacyjne / Payments to be cancelled - identification data
try {
    val result : CancelPaymentsResponse = apiInstance.cancelPayments(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, payment data)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling PISApi#cancelPayments")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling PISApi#cancelPayments")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **kotlin.String**| Wartość nagłówka &#39;Authorization&#39; powinna składać się z &#39;type&#39; + &#39;credentials&#39;, gdzie dla metody z użyciem &#39;type&#39;, token powinien być typu &#39;Bearer&#39;. / The value of the Authorization header should consist of &#39;type&#39; + &#39;credentials&#39;, where for the approach using the &#39;type&#39; token should be &#39;Bearer&#39;. |
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **payment data** | [**CancelPaymentsRequest**](CancelPaymentsRequest.md)| Płatności do anulowania - dane identyfikacyjne / Payments to be cancelled - identification data |

### Return type

[**CancelPaymentsResponse**](CancelPaymentsResponse.md)

### Authorization

[xs2a_auth_aspsp](../README.md#xs2a_auth_aspsp), [xs2a_auth_decoupled](../README.md#xs2a_auth_decoupled)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="cancelRecurringPayment"></a>
# **cancelRecurringPayment**
> CancelRecurringPaymentResponse cancelRecurringPayment(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, recurring payment data)

Anulowanie płatności cyklicznej / Cancelation of recurring payment

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = PISApi()
val authorization : kotlin.String = authorization_example // kotlin.String | Wartość nagłówka 'Authorization' powinna składać się z 'type' + 'credentials', gdzie dla metody z użyciem 'type', token powinien być typu 'Bearer'. / The value of the Authorization header should consist of 'type' + 'credentials', where for the approach using the 'type' token should be 'Bearer'.
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val recurring payment data : CancelRecurringPaymentRequest =  // CancelRecurringPaymentRequest | Płatność cykliczna do anulowania - dane identyfikacyjne / Recurring payment to be cancelled - identification data
try {
    val result : CancelRecurringPaymentResponse = apiInstance.cancelRecurringPayment(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, recurring payment data)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling PISApi#cancelRecurringPayment")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling PISApi#cancelRecurringPayment")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **kotlin.String**| Wartość nagłówka &#39;Authorization&#39; powinna składać się z &#39;type&#39; + &#39;credentials&#39;, gdzie dla metody z użyciem &#39;type&#39;, token powinien być typu &#39;Bearer&#39;. / The value of the Authorization header should consist of &#39;type&#39; + &#39;credentials&#39;, where for the approach using the &#39;type&#39; token should be &#39;Bearer&#39;. |
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **recurring payment data** | [**CancelRecurringPaymentRequest**](CancelRecurringPaymentRequest.md)| Płatność cykliczna do anulowania - dane identyfikacyjne / Recurring payment to be cancelled - identification data |

### Return type

[**CancelRecurringPaymentResponse**](CancelRecurringPaymentResponse.md)

### Authorization

[xs2a_auth_aspsp](../README.md#xs2a_auth_aspsp), [xs2a_auth_decoupled](../README.md#xs2a_auth_decoupled)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="domestic"></a>
# **domestic**
> AddPaymentResponse domestic(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, domesticRequest)

Inicjacja przelewu krajowego / Initiate domestic transfer



### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = PISApi()
val authorization : kotlin.String = authorization_example // kotlin.String | Wartość nagłówka 'Authorization' powinna składać się z 'type' + 'credentials', gdzie dla metody z użyciem 'type', token powinien być typu 'Bearer'. / The value of the Authorization header should consist of 'type' + 'credentials', where for the approach using the 'type' token should be 'Bearer'.
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val domesticRequest : DomesticRequest =  // DomesticRequest | Dane żądania inicjalizacji przelewu krajowego / Data for domestic transfer
try {
    val result : AddPaymentResponse = apiInstance.domestic(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, domesticRequest)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling PISApi#domestic")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling PISApi#domestic")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **kotlin.String**| Wartość nagłówka &#39;Authorization&#39; powinna składać się z &#39;type&#39; + &#39;credentials&#39;, gdzie dla metody z użyciem &#39;type&#39;, token powinien być typu &#39;Bearer&#39;. / The value of the Authorization header should consist of &#39;type&#39; + &#39;credentials&#39;, where for the approach using the &#39;type&#39; token should be &#39;Bearer&#39;. |
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **domesticRequest** | [**DomesticRequest**](DomesticRequest.md)| Dane żądania inicjalizacji przelewu krajowego / Data for domestic transfer |

### Return type

[**AddPaymentResponse**](AddPaymentResponse.md)

### Authorization

[xs2a_auth_aspsp](../README.md#xs2a_auth_aspsp), [xs2a_auth_decoupled](../README.md#xs2a_auth_decoupled)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="eEA"></a>
# **eEA**
> AddPaymentResponse eEA(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, eEARequest)

Inicjacja przelewów zagranicznych SEPA / Initiate SEPA foreign transfers



### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = PISApi()
val authorization : kotlin.String = authorization_example // kotlin.String | Wartość nagłówka 'Authorization' powinna składać się z 'type' + 'credentials', gdzie dla metody z użyciem 'type', token powinien być typu 'Bearer'. / The value of the Authorization header should consist of 'type' + 'credentials', where for the approach using the 'type' token should be 'Bearer'.
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val eEARequest : EEARequest =  // EEARequest | Dane żądania inicjalizacji przelewów zagranicznych SEPA / Data for SEPA foreign transfer
try {
    val result : AddPaymentResponse = apiInstance.eEA(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, eEARequest)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling PISApi#eEA")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling PISApi#eEA")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **kotlin.String**| Wartość nagłówka &#39;Authorization&#39; powinna składać się z &#39;type&#39; + &#39;credentials&#39;, gdzie dla metody z użyciem &#39;type&#39;, token powinien być typu &#39;Bearer&#39;. / The value of the Authorization header should consist of &#39;type&#39; + &#39;credentials&#39;, where for the approach using the &#39;type&#39; token should be &#39;Bearer&#39;. |
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **eEARequest** | [**EEARequest**](EEARequest.md)| Dane żądania inicjalizacji przelewów zagranicznych SEPA / Data for SEPA foreign transfer |

### Return type

[**AddPaymentResponse**](AddPaymentResponse.md)

### Authorization

[xs2a_auth_aspsp](../README.md#xs2a_auth_aspsp), [xs2a_auth_decoupled](../README.md#xs2a_auth_decoupled)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getBundle"></a>
# **getBundle**
> GetBundleResponse getBundle(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, bundle)

Uzyskanie status paczki przelewów / Get the status of bundle of payments

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = PISApi()
val authorization : kotlin.String = authorization_example // kotlin.String | Wartość nagłówka 'Authorization' powinna składać się z 'type' + 'credentials', gdzie dla metody z użyciem 'type', token powinien być typu 'Bearer'. / The value of the Authorization header should consist of 'type' + 'credentials', where for the approach using the 'type' token should be 'Bearer'.
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val bundle : GetBundleRequest =  // GetBundleRequest | Identyfikator paczki przelewów / Bundle ID
try {
    val result : GetBundleResponse = apiInstance.getBundle(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, bundle)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling PISApi#getBundle")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling PISApi#getBundle")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **kotlin.String**| Wartość nagłówka &#39;Authorization&#39; powinna składać się z &#39;type&#39; + &#39;credentials&#39;, gdzie dla metody z użyciem &#39;type&#39;, token powinien być typu &#39;Bearer&#39;. / The value of the Authorization header should consist of &#39;type&#39; + &#39;credentials&#39;, where for the approach using the &#39;type&#39; token should be &#39;Bearer&#39;. |
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **bundle** | [**GetBundleRequest**](GetBundleRequest.md)| Identyfikator paczki przelewów / Bundle ID |

### Return type

[**GetBundleResponse**](GetBundleResponse.md)

### Authorization

[xs2a_auth_aspsp](../README.md#xs2a_auth_aspsp), [xs2a_auth_decoupled](../README.md#xs2a_auth_decoupled)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getMultiplePayments"></a>
# **getMultiplePayments**
> GetMultiplePaymentsResponse getMultiplePayments(acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, payments)

Uzyskanie statusu wielu płatności / Get the status of multiple payments



### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = PISApi()
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val payments : GetMultiplePaymentsRequest =  // GetMultiplePaymentsRequest | Lista identyfikatorów płatności / Payments ID list
try {
    val result : GetMultiplePaymentsResponse = apiInstance.getMultiplePayments(acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, payments)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling PISApi#getMultiplePayments")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling PISApi#getMultiplePayments")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **payments** | [**GetMultiplePaymentsRequest**](GetMultiplePaymentsRequest.md)| Lista identyfikatorów płatności / Payments ID list |

### Return type

[**GetMultiplePaymentsResponse**](GetMultiplePaymentsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getPayment"></a>
# **getPayment**
> GetPaymentResponse getPayment(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, payment)

Uzyskanie statusu płatności / Get the status of payment

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = PISApi()
val authorization : kotlin.String = authorization_example // kotlin.String | Wartość nagłówka 'Authorization' powinna składać się z 'type' + 'credentials', gdzie dla metody z użyciem 'type', token powinien być typu 'Bearer'. / The value of the Authorization header should consist of 'type' + 'credentials', where for the approach using the 'type' token should be 'Bearer'.
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val payment : GetPaymentRequest =  // GetPaymentRequest | Identyfikator płatności / Payment ID
try {
    val result : GetPaymentResponse = apiInstance.getPayment(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, payment)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling PISApi#getPayment")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling PISApi#getPayment")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **kotlin.String**| Wartość nagłówka &#39;Authorization&#39; powinna składać się z &#39;type&#39; + &#39;credentials&#39;, gdzie dla metody z użyciem &#39;type&#39;, token powinien być typu &#39;Bearer&#39;. / The value of the Authorization header should consist of &#39;type&#39; + &#39;credentials&#39;, where for the approach using the &#39;type&#39; token should be &#39;Bearer&#39;. |
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **payment** | [**GetPaymentRequest**](GetPaymentRequest.md)| Identyfikator płatności / Payment ID |

### Return type

[**GetPaymentResponse**](GetPaymentResponse.md)

### Authorization

[xs2a_auth_aspsp](../README.md#xs2a_auth_aspsp), [xs2a_auth_decoupled](../README.md#xs2a_auth_decoupled)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getRecurringPayment"></a>
# **getRecurringPayment**
> GetRecurringPaymentResponse getRecurringPayment(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, recurringPayment)

Uzyskanie status płatności cyklicznej / Get the status of recurring payment

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = PISApi()
val authorization : kotlin.String = authorization_example // kotlin.String | Wartość nagłówka 'Authorization' powinna składać się z 'type' + 'credentials', gdzie dla metody z użyciem 'type', token powinien być typu 'Bearer'. / The value of the Authorization header should consist of 'type' + 'credentials', where for the approach using the 'type' token should be 'Bearer'.
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val recurringPayment : GetRecurringPaymentRequest =  // GetRecurringPaymentRequest | Identyfikacja płatności cyklicznej / Recurring payment identification
try {
    val result : GetRecurringPaymentResponse = apiInstance.getRecurringPayment(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, recurringPayment)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling PISApi#getRecurringPayment")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling PISApi#getRecurringPayment")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **kotlin.String**| Wartość nagłówka &#39;Authorization&#39; powinna składać się z &#39;type&#39; + &#39;credentials&#39;, gdzie dla metody z użyciem &#39;type&#39;, token powinien być typu &#39;Bearer&#39;. / The value of the Authorization header should consist of &#39;type&#39; + &#39;credentials&#39;, where for the approach using the &#39;type&#39; token should be &#39;Bearer&#39;. |
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **recurringPayment** | [**GetRecurringPaymentRequest**](GetRecurringPaymentRequest.md)| Identyfikacja płatności cyklicznej / Recurring payment identification |

### Return type

[**GetRecurringPaymentResponse**](GetRecurringPaymentResponse.md)

### Authorization

[xs2a_auth_aspsp](../README.md#xs2a_auth_aspsp), [xs2a_auth_decoupled](../README.md#xs2a_auth_decoupled)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="nonEEA"></a>
# **nonEEA**
> AddPaymentResponse nonEEA(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, nonEEARequest)

Inicjacja przelewów zagranicznych niezgodnych z SEPA / Initiate non SEPA foreign transfers

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = PISApi()
val authorization : kotlin.String = authorization_example // kotlin.String | Wartość nagłówka 'Authorization' powinna składać się z 'type' + 'credentials', gdzie dla metody z użyciem 'type', token powinien być typu 'Bearer'. / The value of the Authorization header should consist of 'type' + 'credentials', where for the approach using the 'type' token should be 'Bearer'.
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val nonEEARequest : NonEEARequest =  // NonEEARequest | Dane żądania inicjalizacji przelewów zagranicznych niezgodnych z SEPA / Data for non SEPA foreign transfer
try {
    val result : AddPaymentResponse = apiInstance.nonEEA(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, nonEEARequest)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling PISApi#nonEEA")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling PISApi#nonEEA")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **kotlin.String**| Wartość nagłówka &#39;Authorization&#39; powinna składać się z &#39;type&#39; + &#39;credentials&#39;, gdzie dla metody z użyciem &#39;type&#39;, token powinien być typu &#39;Bearer&#39;. / The value of the Authorization header should consist of &#39;type&#39; + &#39;credentials&#39;, where for the approach using the &#39;type&#39; token should be &#39;Bearer&#39;. |
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **nonEEARequest** | [**NonEEARequest**](NonEEARequest.md)| Dane żądania inicjalizacji przelewów zagranicznych niezgodnych z SEPA / Data for non SEPA foreign transfer |

### Return type

[**AddPaymentResponse**](AddPaymentResponse.md)

### Authorization

[xs2a_auth_aspsp](../README.md#xs2a_auth_aspsp), [xs2a_auth_decoupled](../README.md#xs2a_auth_decoupled)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="recurring"></a>
# **recurring**
> RecurringResponse recurring(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, recurringRequest)

Definicja nowej płatności cyklicznej / Defines new recurring payment



### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = PISApi()
val authorization : kotlin.String = authorization_example // kotlin.String | Wartość nagłówka 'Authorization' powinna składać się z 'type' + 'credentials', gdzie dla metody z użyciem 'type', token powinien być typu 'Bearer'. / The value of the Authorization header should consist of 'type' + 'credentials', where for the approach using the 'type' token should be 'Bearer'.
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val recurringRequest : RecurringRequest =  // RecurringRequest | Dane żądania definicji nowej płatności cyklicznej / Data for recurring payment definition
try {
    val result : RecurringResponse = apiInstance.recurring(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, recurringRequest)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling PISApi#recurring")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling PISApi#recurring")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **kotlin.String**| Wartość nagłówka &#39;Authorization&#39; powinna składać się z &#39;type&#39; + &#39;credentials&#39;, gdzie dla metody z użyciem &#39;type&#39;, token powinien być typu &#39;Bearer&#39;. / The value of the Authorization header should consist of &#39;type&#39; + &#39;credentials&#39;, where for the approach using the &#39;type&#39; token should be &#39;Bearer&#39;. |
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **recurringRequest** | [**RecurringRequest**](RecurringRequest.md)| Dane żądania definicji nowej płatności cyklicznej / Data for recurring payment definition |

### Return type

[**RecurringResponse**](RecurringResponse.md)

### Authorization

[xs2a_auth_aspsp](../README.md#xs2a_auth_aspsp), [xs2a_auth_decoupled](../README.md#xs2a_auth_decoupled)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="tax"></a>
# **tax**
> AddPaymentResponse tax(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, taxRequest)

Inicjacja przelewu do organu podatkowego / Initiate tax transfer



### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = PISApi()
val authorization : kotlin.String = authorization_example // kotlin.String | Wartość nagłówka 'Authorization' powinna składać się z 'type' + 'credentials', gdzie dla metody z użyciem 'type', token powinien być typu 'Bearer'. / The value of the Authorization header should consist of 'type' + 'credentials', where for the approach using the 'type' token should be 'Bearer'.
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val taxRequest : TaxRequest =  // TaxRequest | Dane żądania inicjalizacji przelewów do organu podatkowego / Data for tax transfer
try {
    val result : AddPaymentResponse = apiInstance.tax(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, taxRequest)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling PISApi#tax")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling PISApi#tax")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **kotlin.String**| Wartość nagłówka &#39;Authorization&#39; powinna składać się z &#39;type&#39; + &#39;credentials&#39;, gdzie dla metody z użyciem &#39;type&#39;, token powinien być typu &#39;Bearer&#39;. / The value of the Authorization header should consist of &#39;type&#39; + &#39;credentials&#39;, where for the approach using the &#39;type&#39; token should be &#39;Bearer&#39;. |
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **taxRequest** | [**TaxRequest**](TaxRequest.md)| Dane żądania inicjalizacji przelewów do organu podatkowego / Data for tax transfer |

### Return type

[**AddPaymentResponse**](AddPaymentResponse.md)

### Authorization

[xs2a_auth_aspsp](../README.md#xs2a_auth_aspsp), [xs2a_auth_decoupled](../README.md#xs2a_auth_decoupled)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

