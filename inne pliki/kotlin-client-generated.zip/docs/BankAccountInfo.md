
# BankAccountInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bicOrSwift** | **kotlin.String** | Numer BIC/SWIFT Banku / BIC/SWIFT number |  [optional]
**name** | **kotlin.String** | Nazwa Banku / Bank&#39;s name |  [optional]
**address** | [**NameAddress**](NameAddress.md) |  |  [optional]



