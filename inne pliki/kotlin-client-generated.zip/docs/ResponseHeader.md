
# ResponseHeader

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requestId** | [**java.util.UUID**](java.util.UUID.md) | Identyfikator żądania otrzymanego od TPP / Identifier of request received from TPP |  [optional]
**sendDate** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) | Data odpowiedzi, format: YYYY-MM-DDThh:mm:ss[.mmm] / Send date |  [optional]
**isCallback** | **kotlin.Boolean** | Znacznik określający czy odpowiedz zostanie przekazana w formie wywołania zwrotnego. true - gdy odpowiedz w formie wywołania zwrotnego. Inna dopuszczalna wartość to false. |  [optional]



