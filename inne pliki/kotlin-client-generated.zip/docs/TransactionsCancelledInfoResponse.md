
# TransactionsCancelledInfoResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**responseHeader** | [**ResponseHeader**](ResponseHeader.md) |  | 
**transactions** | [**kotlin.Array&lt;TransactionCancelledInfo&gt;**](TransactionCancelledInfo.md) |  |  [optional]
**pageInfo** | [**PageInfo**](PageInfo.md) |  |  [optional]



