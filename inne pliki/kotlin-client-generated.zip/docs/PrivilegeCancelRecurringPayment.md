
# PrivilegeCancelRecurringPayment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**scopeUsageLimit** | [**inline**](#ScopeUsageLimitEnum) | Rodzaj limitu zgody / Type of limit of usages |  [optional]
**recurringPaymentId** | **kotlin.String** | Identyfikator płatności cyklicznej nadany przez ASPSP / Recurring payment identifier set by ASPSP |  [optional]


<a name="ScopeUsageLimitEnum"></a>
## Enum: scopeUsageLimit
Name | Value
---- | -----
scopeUsageLimit | single, multiple



