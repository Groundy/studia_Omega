
# TokenResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**responseHeader** | [**ResponseHeader**](ResponseHeader.md) |  | 
**access_token** | **kotlin.String** | Wartość wygenerowanego tokena dostępowego / Value of the generated access token | 
**token_type** | **kotlin.String** | Typ tokena dostępowego. Dozwolona wartość to Bearer. / Access token type. Allowed value is Bearer. | 
**expires_in** | **kotlin.String** | Czas ważności tokena dostępowego, po którym zostanie on unieważniony. Wartość wyrażona w sekundach, od momentu wygenerowania odpowiedzi. / The validity period of an access token, after which it will be invalidated. Value expressed in seconds, calculated from the moment of generating the response. | 
**refresh_token** | **kotlin.String** | Wartość wygenerowanego tokena służącego do uzyskania nowego tokena dostępowego bez konieczności ponownej autoryzacji / Value of the generated token used to obtain a new access token without the need for re-authorisation |  [optional]
**scope** | **kotlin.String** | Typy zgód które uzyskał TPP. Lista identyfikatorów zgodna ze specyfikacją standardu Polish API. / The types of consents that the TPP has obtained. List of identifiers compatible with the specification of the Polish API standard. |  [optional]
**scope_details** | [**ScopeDetailsOutput**](ScopeDetailsOutput.md) |  | 



