
# AddPaymentResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**responseHeader** | [**ResponseHeader**](ResponseHeader.md) |  | 
**paymentId** | **kotlin.String** | Identyfiaktor płatności / Payment ID | 
**generalStatus** | [**PaymentStatus**](PaymentStatus.md) |  | 
**detailedStatus** | **kotlin.String** | Status płatności / Detailed payment status | 



