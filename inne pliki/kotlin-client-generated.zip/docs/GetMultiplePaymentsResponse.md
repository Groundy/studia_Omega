
# GetMultiplePaymentsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**responseHeader** | [**ResponseHeader**](ResponseHeader.md) |  | 
**payments** | [**kotlin.Array&lt;PaymentInfo&gt;**](PaymentInfo.md) |  |  [optional]



