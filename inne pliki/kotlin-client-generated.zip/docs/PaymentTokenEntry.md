
# PaymentTokenEntry

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**paymentId** | **kotlin.String** | Identyfikator płatności. Wymagany warunkowo - jeśli TPP otrzymał ten identyfikator od ASPSP. / Identifier of the payment. Conditionally required - in case TPP has received this identifier from ASPSP. |  [optional]
**tppTransactionId** | **kotlin.String** | Identyfikator transakcji nadany przez TPP. Wymagany warunkowo - jeśli TPP nie otrzymał identyfikatora paymentId od ASPSP. / Identifier of transaction established by TPP. Conditionally required - in case TPP has not received paymentId from ASPSP. |  [optional]
**accessToken** | **kotlin.String** | Access token użyty do zainicjowania płatności / Access token used to initiate payment | 



