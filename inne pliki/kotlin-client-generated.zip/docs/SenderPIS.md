
# SenderPIS

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountNumber** | [**AccountNumber**](AccountNumber.md) |  |  [optional]
**nameAddress** | [**NameAddress**](NameAddress.md) |  |  [optional]



