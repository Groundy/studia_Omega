
# AccountsRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requestHeader** | [**RequestHeaderAISCallback**](RequestHeaderAISCallback.md) |  | 
**typeOfPsuRelation** | [**inline**](#TypeOfPsuRelationEnum) | Używane w celu filtrowania - typ relacji PSU do rachunku / Used for filtering the results - type of relation between PSU and an Account |  [optional]
**pageId** | **kotlin.String** | Używane w celu stronicowania danych: identyfikator strony, która ma zostać zwrócona w odpowiedzi / Used for paging the results. Identifier of the page to be returned in the response. |  [optional]
**perPage** | **kotlin.Int** | Używane w celu stronicowania danych: wielkość strony danych / Page size (paging info) |  [optional]


<a name="TypeOfPsuRelationEnum"></a>
## Enum: typeOfPsuRelation
Name | Value
---- | -----
typeOfPsuRelation | Owner, Borrower, Guarantor, ProxyOwner, Beneficiary, Trustee



