
# TransactionsDoneInfoResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**responseHeader** | [**ResponseHeader**](ResponseHeader.md) |  | 
**transactions** | [**kotlin.Array&lt;TransactionInfo&gt;**](TransactionInfo.md) |  |  [optional]
**pageInfo** | [**PageInfo**](PageInfo.md) |  |  [optional]



