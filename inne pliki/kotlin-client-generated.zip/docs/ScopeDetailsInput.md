
# ScopeDetailsInput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**privilegeList** | [**kotlin.Array&lt;ScopeDetailsInputPrivilegeList&gt;**](ScopeDetailsInputPrivilegeList.md) | Lista struktur opisujących szczegóły zgody. Lista nie może zawierać dwóch lub więcej struktur, które dla tego samego rachunku zawierają różne definicje tej samej zgody. Wymagane warunkowo - w przypadku procesu uzyskiwania nowej zgody. / The list of structures describing details of consent. The list cannot consist of of two or more structures with different definitions of the same consent for the same account number. Conditionally required - in case of process of obtaining new consent. |  [optional]
**scopeGroupType** | [**inline**](#ScopeGroupTypeEnum) | Rodzaj zgody / Type of consent | 
**consentId** | **kotlin.String** | Identyfikator zgody / Id of consent | 
**scopeTimeLimit** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) | Data ważności zgody / consent valid until, YYYY-MM-DDThh:mm:ss[.mmm] | 
**throttlingPolicy** | [**inline**](#ThrottlingPolicyEnum) | Polityka przepustowości / Throttling policy | 


<a name="ScopeGroupTypeEnum"></a>
## Enum: scopeGroupType
Name | Value
---- | -----
scopeGroupType | ais-accounts, ais, pis


<a name="ThrottlingPolicyEnum"></a>
## Enum: throttlingPolicy
Name | Value
---- | -----
throttlingPolicy | psd2Regulatory



