
# PrivilegeForeignTransferNonEEA

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**scopeUsageLimit** | [**inline**](#ScopeUsageLimitEnum) | Rodzaj limitu zgody / Type of limit of usages |  [optional]
**recipient** | [**RecipientPISForeign**](RecipientPISForeign.md) |  |  [optional]
**recipientBank** | [**Bank**](Bank.md) |  |  [optional]
**sender** | [**SenderPIS**](SenderPIS.md) |  |  [optional]
**transferData** | [**TransferDataCurrencyRequired**](TransferDataCurrencyRequired.md) |  |  [optional]
**transferCharges** | **kotlin.String** | Klauzula kosztowa / The cost clause |  [optional]
**deliveryMode** | [**inline**](#DeliveryModeEnum) | Tryb pilności / Urgency mode |  [optional]
**system** | [**inline**](#SystemEnum) | Droga jaką przelew ma być rozliczony / The way the transfer should be settled |  [optional]
**hold** | **kotlin.Boolean** | Czy założyć blokadę (w przypadku np. zlecenia przelewu w dniu wolnym) / Indicates if payment should be held |  [optional]
**executionMode** | [**inline**](#ExecutionModeEnum) | Tryb realizacji płatności. Nadrzędna informacja decydująca o tym w jakim trybie zostanie zrealizowana płatność. / Payment execution mode. The superior information deciding which mode is to be used to execute payment. |  [optional]


<a name="ScopeUsageLimitEnum"></a>
## Enum: scopeUsageLimit
Name | Value
---- | -----
scopeUsageLimit | single, multiple


<a name="DeliveryModeEnum"></a>
## Enum: deliveryMode
Name | Value
---- | -----
deliveryMode | ExpressD0, UrgentD1, StandardD2


<a name="SystemEnum"></a>
## Enum: system
Name | Value
---- | -----
system | Swift


<a name="ExecutionModeEnum"></a>
## Enum: executionMode
Name | Value
---- | -----
executionMode | Immediate, FutureDated



