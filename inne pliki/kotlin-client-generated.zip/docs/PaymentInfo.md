
# PaymentInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**paymentId** | **kotlin.String** | Identyfiaktor płatności / Payment ID | 
**tppTransactionId** | **kotlin.String** | ID transakcji nadany przez TPP / Transaction ID (TPP) | 
**generalStatus** | [**PaymentStatus**](PaymentStatus.md) |  | 
**detailedStatus** | **kotlin.String** | Szczegółowy status płatności / Detailed payment status | 
**executionMode** | [**inline**](#ExecutionModeEnum) | Tryb realizacji płatności. Nadrzędna informacja decydująca o tym w jakim trybie zostanie zrealizowana płatność. / Payment execution mode. The superior information deciding which mode is to be used to execute payment. | 


<a name="ExecutionModeEnum"></a>
## Enum: executionMode
Name | Value
---- | -----
executionMode | Immediate, FutureDated



