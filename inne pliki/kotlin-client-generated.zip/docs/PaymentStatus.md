
# PaymentStatus

## Enum


    * `submitted` (value: `"submitted"`)

    * `cancelled` (value: `"cancelled"`)

    * `pending` (value: `"pending"`)

    * `done` (value: `"done"`)

    * `rejected` (value: `"rejected"`)

    * `scheduled` (value: `"scheduled"`)



