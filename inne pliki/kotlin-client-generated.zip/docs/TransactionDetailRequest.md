
# TransactionDetailRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requestHeader** | [**RequestHeaderAIS**](RequestHeaderAIS.md) |  | 
**itemId** | **kotlin.String** | ID elementu (transakcji lub blokadzie) nadany przez ASPSP / Element (transaction or hold) ID (ASPSP) | 
**accountNumber** | **kotlin.String** | Numer konta nadawcy / Sender account number | 
**bookingDate** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) | Data zaksięgowania operacji, YYYY-MM-DDThh:mm:ss[.mmm] / Transaction booking date |  [optional]



