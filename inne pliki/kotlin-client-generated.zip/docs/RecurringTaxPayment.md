
# RecurringTaxPayment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recipient** | [**RecipientPIS**](RecipientPIS.md) |  | 
**sender** | [**SenderPIS**](SenderPIS.md) |  | 
**transferData** | [**TransferDataCurrencyRequiredTax**](TransferDataCurrencyRequiredTax.md) |  | 
**usInfo** | [**TransactionInfoTax**](TransactionInfoTax.md) |  |  [optional]
**deliveryMode** | [**inline**](#DeliveryModeEnum) | Tryb pilności / Urgency mode | 
**system** | [**inline**](#SystemEnum) | Droga jaką przelew ma być rozliczony / The way the transfer should be settled | 
**hold** | **kotlin.Boolean** | Czy założyć blokadę (w przypadku np. zlecenia przelewu w dniu wolnym) / Indicates if payment should be held |  [optional]


<a name="DeliveryModeEnum"></a>
## Enum: deliveryMode
Name | Value
---- | -----
deliveryMode | ExpressD0, StandardD1


<a name="SystemEnum"></a>
## Enum: system
Name | Value
---- | -----
system | Elixir, ExpressElixir



