# AISApi

All URIs are relative to *https://apiHost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**deleteConsent**](AISApi.md#deleteConsent) | **POST** /v3_0.1/accounts/v3_0.1/deleteConsent | Usuwa zezwolenie / Removes consent
[**getAccount**](AISApi.md#getAccount) | **POST** /v3_0.1/accounts/v3_0.1/getAccount | Uzyskanie szczegółowych informacji o koncie płatniczym użytkownika / Get detailed information about user payment account
[**getAccounts**](AISApi.md#getAccounts) | **POST** /v3_0.1/accounts/v3_0.1/getAccounts | Uzyskanie informacji na temat wszystkich kont płatniczych użytkownika / Get information about all user&#39;s payment account
[**getHolds**](AISApi.md#getHolds) | **POST** /v3_0.1/accounts/v3_0.1/getHolds | Pobranie informacji o blokadach na koncie użytkownika / Get list of user&#39;s held operations
[**getTransactionDetail**](AISApi.md#getTransactionDetail) | **POST** /v3_0.1/accounts/v3_0.1/getTransactionDetail | Pobranie szczegółowych informacji o pojedynczej transkacji użytkownika / Get detailed information about user&#39;s single transaction
[**getTransactionsCancelled**](AISApi.md#getTransactionsCancelled) | **POST** /v3_0.1/accounts/v3_0.1/getTransactionsCancelled | Pobranie informacji o anulowanych transakcjach użytkownika / Get list of user cancelled transactions
[**getTransactionsDone**](AISApi.md#getTransactionsDone) | **POST** /v3_0.1/accounts/v3_0.1/getTransactionsDone | Pobranie informacji o zaksięgowanych transakcjach użytkownika / Get list of user done transactions
[**getTransactionsPending**](AISApi.md#getTransactionsPending) | **POST** /v3_0.1/accounts/v3_0.1/getTransactionsPending | Pobranie informacji o oczekujących transakcjach użytkownika / Get list of user&#39;s pending transactions
[**getTransactionsRejected**](AISApi.md#getTransactionsRejected) | **POST** /v3_0.1/accounts/v3_0.1/getTransactionsRejected | Pobranie informacji o odrzuconych transakcjach użytkownika / Get list of user&#39;s rejected transactions
[**getTransactionsScheduled**](AISApi.md#getTransactionsScheduled) | **POST** /v3_0.1/accounts/v3_0.1/getTransactionsScheduled | Pobranie informacji o zaplanowanych transakcjach użytkownika / Get list of user scheduled transactions


<a name="deleteConsent"></a>
# **deleteConsent**
> deleteConsent(acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, deleteConsentRequest)

Usuwa zezwolenie / Removes consent

Usuwa zezwolenie / Removes consent

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = AISApi()
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val deleteConsentRequest : DeleteConsentRequest =  // DeleteConsentRequest | Dane żądania usunięcia zgody / Data for delete Consent Request
try {
    apiInstance.deleteConsent(acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, deleteConsentRequest)
} catch (e: ClientException) {
    println("4xx response calling AISApi#deleteConsent")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AISApi#deleteConsent")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **deleteConsentRequest** | [**DeleteConsentRequest**](DeleteConsentRequest.md)| Dane żądania usunięcia zgody / Data for delete Consent Request |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getAccount"></a>
# **getAccount**
> AccountResponse getAccount(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, getAccountRequest)

Uzyskanie szczegółowych informacji o koncie płatniczym użytkownika / Get detailed information about user payment account

Identyfikacja użytkownika na podstawie tokena dostępu / User identification based on access token

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = AISApi()
val authorization : kotlin.String = authorization_example // kotlin.String | Wartość nagłówka 'Authorization' powinna składać się z 'type' + 'credentials', gdzie dla metody z użyciem 'type', token powinien być typu 'Bearer'. / The value of the Authorization header should consist of 'type' + 'credentials', where for the approach using the 'type' token should be 'Bearer'.
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val getAccountRequest : AccountInfoRequest =  // AccountInfoRequest | Dane żądania o szczegóły konta płatniczego / Data for Account Request
try {
    val result : AccountResponse = apiInstance.getAccount(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, getAccountRequest)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AISApi#getAccount")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AISApi#getAccount")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **kotlin.String**| Wartość nagłówka &#39;Authorization&#39; powinna składać się z &#39;type&#39; + &#39;credentials&#39;, gdzie dla metody z użyciem &#39;type&#39;, token powinien być typu &#39;Bearer&#39;. / The value of the Authorization header should consist of &#39;type&#39; + &#39;credentials&#39;, where for the approach using the &#39;type&#39; token should be &#39;Bearer&#39;. |
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **getAccountRequest** | [**AccountInfoRequest**](AccountInfoRequest.md)| Dane żądania o szczegóły konta płatniczego / Data for Account Request |

### Return type

[**AccountResponse**](AccountResponse.md)

### Authorization

[xs2a_auth_aspsp](../README.md#xs2a_auth_aspsp), [xs2a_auth_decoupled](../README.md#xs2a_auth_decoupled)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getAccounts"></a>
# **getAccounts**
> AccountsResponse getAccounts(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, getAccountsRequest)

Uzyskanie informacji na temat wszystkich kont płatniczych użytkownika / Get information about all user&#39;s payment account

Identyfikacja użytkownika na podstawie tokena dostępu / User identification based on access token

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = AISApi()
val authorization : kotlin.String = authorization_example // kotlin.String | Wartość nagłówka 'Authorization' powinna składać się z 'type' + 'credentials', gdzie dla metody z użyciem 'type', token powinien być typu 'Bearer'. / The value of the Authorization header should consist of 'type' + 'credentials', where for the approach using the 'type' token should be 'Bearer'.
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val getAccountsRequest : AccountsRequest =  // AccountsRequest | Dane żądania o uzyskanie informacji o kontach płatniczych / Data for Accounts Request
try {
    val result : AccountsResponse = apiInstance.getAccounts(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, getAccountsRequest)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AISApi#getAccounts")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AISApi#getAccounts")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **kotlin.String**| Wartość nagłówka &#39;Authorization&#39; powinna składać się z &#39;type&#39; + &#39;credentials&#39;, gdzie dla metody z użyciem &#39;type&#39;, token powinien być typu &#39;Bearer&#39;. / The value of the Authorization header should consist of &#39;type&#39; + &#39;credentials&#39;, where for the approach using the &#39;type&#39; token should be &#39;Bearer&#39;. |
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **getAccountsRequest** | [**AccountsRequest**](AccountsRequest.md)| Dane żądania o uzyskanie informacji o kontach płatniczych / Data for Accounts Request |

### Return type

[**AccountsResponse**](AccountsResponse.md)

### Authorization

[xs2a_auth_aspsp](../README.md#xs2a_auth_aspsp), [xs2a_auth_decoupled](../README.md#xs2a_auth_decoupled)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getHolds"></a>
# **getHolds**
> HoldInfoResponse getHolds(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, getHoldsRequest)

Pobranie informacji o blokadach na koncie użytkownika / Get list of user&#39;s held operations



### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = AISApi()
val authorization : kotlin.String = authorization_example // kotlin.String | Wartość nagłówka 'Authorization' powinna składać się z 'type' + 'credentials', gdzie dla metody z użyciem 'type', token powinien być typu 'Bearer'. / The value of the Authorization header should consist of 'type' + 'credentials', where for the approach using the 'type' token should be 'Bearer'.
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val getHoldsRequest : HoldRequest =  // HoldRequest | Dane żądania o informacje o blokadach na koncie / Data for hold Request
try {
    val result : HoldInfoResponse = apiInstance.getHolds(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, getHoldsRequest)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AISApi#getHolds")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AISApi#getHolds")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **kotlin.String**| Wartość nagłówka &#39;Authorization&#39; powinna składać się z &#39;type&#39; + &#39;credentials&#39;, gdzie dla metody z użyciem &#39;type&#39;, token powinien być typu &#39;Bearer&#39;. / The value of the Authorization header should consist of &#39;type&#39; + &#39;credentials&#39;, where for the approach using the &#39;type&#39; token should be &#39;Bearer&#39;. |
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **getHoldsRequest** | [**HoldRequest**](HoldRequest.md)| Dane żądania o informacje o blokadach na koncie / Data for hold Request |

### Return type

[**HoldInfoResponse**](HoldInfoResponse.md)

### Authorization

[xs2a_auth_aspsp](../README.md#xs2a_auth_aspsp), [xs2a_auth_decoupled](../README.md#xs2a_auth_decoupled)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getTransactionDetail"></a>
# **getTransactionDetail**
> TransactionDetailResponse getTransactionDetail(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, getTransationDetailRequest)

Pobranie szczegółowych informacji o pojedynczej transkacji użytkownika / Get detailed information about user&#39;s single transaction



### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = AISApi()
val authorization : kotlin.String = authorization_example // kotlin.String | Wartość nagłówka 'Authorization' powinna składać się z 'type' + 'credentials', gdzie dla metody z użyciem 'type', token powinien być typu 'Bearer'. / The value of the Authorization header should consist of 'type' + 'credentials', where for the approach using the 'type' token should be 'Bearer'.
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val getTransationDetailRequest : TransactionDetailRequest =  // TransactionDetailRequest | Dane żądania o szczegółowe informacje o transakcji / Data for transation detail Request
try {
    val result : TransactionDetailResponse = apiInstance.getTransactionDetail(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, getTransationDetailRequest)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AISApi#getTransactionDetail")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AISApi#getTransactionDetail")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **kotlin.String**| Wartość nagłówka &#39;Authorization&#39; powinna składać się z &#39;type&#39; + &#39;credentials&#39;, gdzie dla metody z użyciem &#39;type&#39;, token powinien być typu &#39;Bearer&#39;. / The value of the Authorization header should consist of &#39;type&#39; + &#39;credentials&#39;, where for the approach using the &#39;type&#39; token should be &#39;Bearer&#39;. |
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **getTransationDetailRequest** | [**TransactionDetailRequest**](TransactionDetailRequest.md)| Dane żądania o szczegółowe informacje o transakcji / Data for transation detail Request |

### Return type

[**TransactionDetailResponse**](TransactionDetailResponse.md)

### Authorization

[xs2a_auth_aspsp](../README.md#xs2a_auth_aspsp), [xs2a_auth_decoupled](../README.md#xs2a_auth_decoupled)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getTransactionsCancelled"></a>
# **getTransactionsCancelled**
> TransactionsCancelledInfoResponse getTransactionsCancelled(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, getTransactionsCancelledRequest)

Pobranie informacji o anulowanych transakcjach użytkownika / Get list of user cancelled transactions



### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = AISApi()
val authorization : kotlin.String = authorization_example // kotlin.String | Wartość nagłówka 'Authorization' powinna składać się z 'type' + 'credentials', gdzie dla metody z użyciem 'type', token powinien być typu 'Bearer'. / The value of the Authorization header should consist of 'type' + 'credentials', where for the approach using the 'type' token should be 'Bearer'.
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val getTransactionsCancelledRequest : TransactionInfoRequest =  // TransactionInfoRequest | Dane żądania o informacje o anulowanych transakcjach / Data for Transactions Cancelled Request
try {
    val result : TransactionsCancelledInfoResponse = apiInstance.getTransactionsCancelled(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, getTransactionsCancelledRequest)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AISApi#getTransactionsCancelled")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AISApi#getTransactionsCancelled")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **kotlin.String**| Wartość nagłówka &#39;Authorization&#39; powinna składać się z &#39;type&#39; + &#39;credentials&#39;, gdzie dla metody z użyciem &#39;type&#39;, token powinien być typu &#39;Bearer&#39;. / The value of the Authorization header should consist of &#39;type&#39; + &#39;credentials&#39;, where for the approach using the &#39;type&#39; token should be &#39;Bearer&#39;. |
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **getTransactionsCancelledRequest** | [**TransactionInfoRequest**](TransactionInfoRequest.md)| Dane żądania o informacje o anulowanych transakcjach / Data for Transactions Cancelled Request |

### Return type

[**TransactionsCancelledInfoResponse**](TransactionsCancelledInfoResponse.md)

### Authorization

[xs2a_auth_aspsp](../README.md#xs2a_auth_aspsp), [xs2a_auth_decoupled](../README.md#xs2a_auth_decoupled)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getTransactionsDone"></a>
# **getTransactionsDone**
> TransactionsDoneInfoResponse getTransactionsDone(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, getTransactionsDoneRequest)

Pobranie informacji o zaksięgowanych transakcjach użytkownika / Get list of user done transactions



### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = AISApi()
val authorization : kotlin.String = authorization_example // kotlin.String | Wartość nagłówka 'Authorization' powinna składać się z 'type' + 'credentials', gdzie dla metody z użyciem 'type', token powinien być typu 'Bearer'. / The value of the Authorization header should consist of 'type' + 'credentials', where for the approach using the 'type' token should be 'Bearer'.
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val getTransactionsDoneRequest : TransactionInfoRequest =  // TransactionInfoRequest | Dane żądania o informacje o zaksiegowanych transakcjach / Data for Transactions Done Request
try {
    val result : TransactionsDoneInfoResponse = apiInstance.getTransactionsDone(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, getTransactionsDoneRequest)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AISApi#getTransactionsDone")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AISApi#getTransactionsDone")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **kotlin.String**| Wartość nagłówka &#39;Authorization&#39; powinna składać się z &#39;type&#39; + &#39;credentials&#39;, gdzie dla metody z użyciem &#39;type&#39;, token powinien być typu &#39;Bearer&#39;. / The value of the Authorization header should consist of &#39;type&#39; + &#39;credentials&#39;, where for the approach using the &#39;type&#39; token should be &#39;Bearer&#39;. |
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **getTransactionsDoneRequest** | [**TransactionInfoRequest**](TransactionInfoRequest.md)| Dane żądania o informacje o zaksiegowanych transakcjach / Data for Transactions Done Request |

### Return type

[**TransactionsDoneInfoResponse**](TransactionsDoneInfoResponse.md)

### Authorization

[xs2a_auth_aspsp](../README.md#xs2a_auth_aspsp), [xs2a_auth_decoupled](../README.md#xs2a_auth_decoupled)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getTransactionsPending"></a>
# **getTransactionsPending**
> TransactionPendingInfoResponse getTransactionsPending(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, getTransactionsPendingRequest)

Pobranie informacji o oczekujących transakcjach użytkownika / Get list of user&#39;s pending transactions



### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = AISApi()
val authorization : kotlin.String = authorization_example // kotlin.String | Wartość nagłówka 'Authorization' powinna składać się z 'type' + 'credentials', gdzie dla metody z użyciem 'type', token powinien być typu 'Bearer'. / The value of the Authorization header should consist of 'type' + 'credentials', where for the approach using the 'type' token should be 'Bearer'.
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val getTransactionsPendingRequest : TransactionInfoRequest =  // TransactionInfoRequest | Dane żądania o informacje o oczekujących transakcjach / Data for Transactions Pending Request
try {
    val result : TransactionPendingInfoResponse = apiInstance.getTransactionsPending(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, getTransactionsPendingRequest)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AISApi#getTransactionsPending")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AISApi#getTransactionsPending")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **kotlin.String**| Wartość nagłówka &#39;Authorization&#39; powinna składać się z &#39;type&#39; + &#39;credentials&#39;, gdzie dla metody z użyciem &#39;type&#39;, token powinien być typu &#39;Bearer&#39;. / The value of the Authorization header should consist of &#39;type&#39; + &#39;credentials&#39;, where for the approach using the &#39;type&#39; token should be &#39;Bearer&#39;. |
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **getTransactionsPendingRequest** | [**TransactionInfoRequest**](TransactionInfoRequest.md)| Dane żądania o informacje o oczekujących transakcjach / Data for Transactions Pending Request |

### Return type

[**TransactionPendingInfoResponse**](TransactionPendingInfoResponse.md)

### Authorization

[xs2a_auth_aspsp](../README.md#xs2a_auth_aspsp), [xs2a_auth_decoupled](../README.md#xs2a_auth_decoupled)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getTransactionsRejected"></a>
# **getTransactionsRejected**
> TransactionRejectedInfoResponse getTransactionsRejected(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, getTransactionsRejectedRequest)

Pobranie informacji o odrzuconych transakcjach użytkownika / Get list of user&#39;s rejected transactions



### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = AISApi()
val authorization : kotlin.String = authorization_example // kotlin.String | Wartość nagłówka 'Authorization' powinna składać się z 'type' + 'credentials', gdzie dla metody z użyciem 'type', token powinien być typu 'Bearer'. / The value of the Authorization header should consist of 'type' + 'credentials', where for the approach using the 'type' token should be 'Bearer'.
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val getTransactionsRejectedRequest : TransactionInfoRequest =  // TransactionInfoRequest | Dane żądania o informacje o odrzuconych transakcjach / Data for Transactions Rejected Request
try {
    val result : TransactionRejectedInfoResponse = apiInstance.getTransactionsRejected(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, getTransactionsRejectedRequest)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AISApi#getTransactionsRejected")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AISApi#getTransactionsRejected")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **kotlin.String**| Wartość nagłówka &#39;Authorization&#39; powinna składać się z &#39;type&#39; + &#39;credentials&#39;, gdzie dla metody z użyciem &#39;type&#39;, token powinien być typu &#39;Bearer&#39;. / The value of the Authorization header should consist of &#39;type&#39; + &#39;credentials&#39;, where for the approach using the &#39;type&#39; token should be &#39;Bearer&#39;. |
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **getTransactionsRejectedRequest** | [**TransactionInfoRequest**](TransactionInfoRequest.md)| Dane żądania o informacje o odrzuconych transakcjach / Data for Transactions Rejected Request |

### Return type

[**TransactionRejectedInfoResponse**](TransactionRejectedInfoResponse.md)

### Authorization

[xs2a_auth_aspsp](../README.md#xs2a_auth_aspsp), [xs2a_auth_decoupled](../README.md#xs2a_auth_decoupled)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getTransactionsScheduled"></a>
# **getTransactionsScheduled**
> TransactionsScheduledInfoResponse getTransactionsScheduled(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, getTransactionsScheduledRequest)

Pobranie informacji o zaplanowanych transakcjach użytkownika / Get list of user scheduled transactions



### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = AISApi()
val authorization : kotlin.String = authorization_example // kotlin.String | Wartość nagłówka 'Authorization' powinna składać się z 'type' + 'credentials', gdzie dla metody z użyciem 'type', token powinien być typu 'Bearer'. / The value of the Authorization header should consist of 'type' + 'credentials', where for the approach using the 'type' token should be 'Bearer'.
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val getTransactionsScheduledRequest : TransactionInfoRequest =  // TransactionInfoRequest | Dane żądania o informacje o zaplanowanych transakcjach / Data for Transactions Scheduled Request
try {
    val result : TransactionsScheduledInfoResponse = apiInstance.getTransactionsScheduled(authorization, acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, getTransactionsScheduledRequest)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AISApi#getTransactionsScheduled")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AISApi#getTransactionsScheduled")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **kotlin.String**| Wartość nagłówka &#39;Authorization&#39; powinna składać się z &#39;type&#39; + &#39;credentials&#39;, gdzie dla metody z użyciem &#39;type&#39;, token powinien być typu &#39;Bearer&#39;. / The value of the Authorization header should consist of &#39;type&#39; + &#39;credentials&#39;, where for the approach using the &#39;type&#39; token should be &#39;Bearer&#39;. |
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **getTransactionsScheduledRequest** | [**TransactionInfoRequest**](TransactionInfoRequest.md)| Dane żądania o informacje o zaplanowanych transakcjach / Data for Transactions Scheduled Request |

### Return type

[**TransactionsScheduledInfoResponse**](TransactionsScheduledInfoResponse.md)

### Authorization

[xs2a_auth_aspsp](../README.md#xs2a_auth_aspsp), [xs2a_auth_decoupled](../README.md#xs2a_auth_decoupled)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

