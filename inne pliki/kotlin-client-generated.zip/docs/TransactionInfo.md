
# TransactionInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transactionCategory** | [**inline**](#TransactionCategoryEnum) | Kategoria transakcji uznanie/obciążenie / Transaction category (credit/debit) | 
**transactionStatus** | [**DictionaryItem**](DictionaryItem.md) |  |  [optional]
**initiator** | [**NameAddress**](NameAddress.md) |  |  [optional]
**sender** | [**SenderRecipient**](SenderRecipient.md) |  |  [optional]
**recipient** | [**SenderRecipient**](SenderRecipient.md) |  |  [optional]
**bookingDate** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) | Data księgowania, YYYY-MM-DDThh:mm:ss[.mmm]. Wymagane warunkowo - w przypadku transakcji zaksięgowanych. / Booking date. Conditional - in case of booked transactions. |  [optional]
**postTransactionBalance** | **kotlin.String** | Saldo rachunku po transakcji. Wymagane warunkowo - w przypadku transakcji zaksięgowanych. / Account balance after the transaction is booked. Conditional - in case of booked transactions. |  [optional]


<a name="TransactionCategoryEnum"></a>
## Enum: transactionCategory
Name | Value
---- | -----
transactionCategory | CREDIT, DEBIT



