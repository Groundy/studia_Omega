
# AccountsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**responseHeader** | [**ResponseHeader**](ResponseHeader.md) |  | 
**accounts** | [**kotlin.Array&lt;AccountBaseInfo&gt;**](AccountBaseInfo.md) |  |  [optional]
**pageInfo** | [**PageInfo**](PageInfo.md) |  |  [optional]



