
# AccountPsuRelation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**typeOfRelation** | [**inline**](#TypeOfRelationEnum) | Typ relacji PSU do rachunku / Type of relation between PSU and an Account | 
**typeOfProxy** | [**inline**](#TypeOfProxyEnum) | Typ pełnomocnictwa PSU do rachunku płatniczego. Wymagane gdy typ relacji to Pełnomocnik na rachunku. / Type of proxy. Required for ProxyOwner being a type of PSU relation. |  [optional]
**stake** | **kotlin.Int** | Wartość całkowita, wyrażona w procentach, określająca udział PSU w środkach na rachunku lub jego odpowiedzialności w przypadku produktów kredytowych. Dotyczy relacji Owner, Borrower, Guarantor. Opcjonalne. / Integer percentage value defining a participation of PSU in liabilities (in case of credit products) or in ownership of funds on the account. Applicable for the following types of PSU relations: Owner, Borrower, Guarantor. Optional. |  [optional]


<a name="TypeOfRelationEnum"></a>
## Enum: typeOfRelation
Name | Value
---- | -----
typeOfRelation | Owner, Borrower, Guarantor, ProxyOwner, Beneficiary, Trustee


<a name="TypeOfProxyEnum"></a>
## Enum: typeOfProxy
Name | Value
---- | -----
typeOfProxy | General, Special, Administrator, User



