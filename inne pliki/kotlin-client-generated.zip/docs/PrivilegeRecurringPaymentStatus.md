
# PrivilegeRecurringPaymentStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**scopeUsageLimit** | [**inline**](#ScopeUsageLimitEnum) | Rodzaj limitu zgody / Type of limit of usages |  [optional]
**recurringPaymentId** | **kotlin.String** | Identyfikator płatności cyklicznej nadany przez APSP / Recurring payment identifier set by ASPSP |  [optional]
**tppRecurringPaymentId** | **kotlin.String** | Identyfikator płatności cyklicznej nadany przez TPP / Recurring payment identifier set by TPP |  [optional]


<a name="ScopeUsageLimitEnum"></a>
## Enum: scopeUsageLimit
Name | Value
---- | -----
scopeUsageLimit | single, multiple



