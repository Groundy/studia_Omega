
# AccountInfoRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requestHeader** | [**RequestHeaderAIS**](RequestHeaderAIS.md) |  | 
**accountNumber** | **kotlin.String** | Numer rachunku / Account number | 



