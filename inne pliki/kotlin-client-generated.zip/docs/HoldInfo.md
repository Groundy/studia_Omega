
# HoldInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**holdExpirationDate** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) | Data ważności blokady, YYYY-MM-DDThh:mm:ss[.mmm] / Expiration date of hold |  [optional]
**initiator** | [**NameAddress**](NameAddress.md) |  |  [optional]
**sender** | [**SenderRecipient**](SenderRecipient.md) |  |  [optional]
**recipient** | [**SenderRecipient**](SenderRecipient.md) |  |  [optional]



