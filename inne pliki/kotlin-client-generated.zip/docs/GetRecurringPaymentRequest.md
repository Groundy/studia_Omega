
# GetRecurringPaymentRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requestHeader** | [**RequestHeader**](RequestHeader.md) |  | 
**recurringPaymentId** | **kotlin.String** | Identyfikator płatności cyklicznej nadany przez ASPSP. Wymagany warunkowo - jeśli TPP otrzymał ten identyfikator od ASPSP. / Recurring payment identifier set by ASPSP. Conditionally required - in case TPP has received this identifier from ASPSP. |  [optional]
**tppRecurringPaymentId** | **kotlin.String** | Identyfikator płatności cyklicznej nadany przez TPP. Wymagany warunkowo - jeśli TPP nie otrzymał identyfikatora recurringPaymentId od ASPSP. / Recurring payment identifier set by TPP. Conditionally required - in case TPP has not received recurringPaymentId from ASPSP. |  [optional]



