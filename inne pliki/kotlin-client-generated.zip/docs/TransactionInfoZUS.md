
# TransactionInfoZUS

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payerInfo** | [**SocialSecurityPayor**](SocialSecurityPayor.md) |  |  [optional]
**contributionType** | **kotlin.String** | Typ wpłaty / Contribution type |  [optional]
**contributionId** | **kotlin.String** | Numer deklaracji / Contribution identifier |  [optional]
**contributionPeriod** | **kotlin.String** | Okres deklaracji / Contribution period, Format: MMYYYY |  [optional]
**paymentTypeId** | **kotlin.String** | Identyfikator typu płatności / Payment type ID |  [optional]
**obligationId** | **kotlin.String** | Numer tytułu wykonawczego / Obligation identifier or number |  [optional]



