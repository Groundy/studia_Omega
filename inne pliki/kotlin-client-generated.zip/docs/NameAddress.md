
# NameAddress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **kotlin.Array&lt;kotlin.String&gt;** |  |  [optional]



