
# TransactionDetailResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**responseHeader** | [**ResponseHeader**](ResponseHeader.md) |  | 
**baseInfo** | [**TransactionInfo**](TransactionInfo.md) |  | 
**zusInfo** | [**TransactionInfoZUS**](TransactionInfoZUS.md) |  |  [optional]
**usInfo** | [**TransactionInfoTax**](TransactionInfoTax.md) |  |  [optional]
**cardInfo** | [**TransactionInfoCard**](TransactionInfoCard.md) |  |  [optional]
**currencyDate** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) | Data kursu waluty, YYYY-MM-DDThh:mm:ss[.mmm] / Date of the currency exchange rate |  [optional]
**transactionRate** | [**kotlin.Array&lt;CurrencyRate&gt;**](CurrencyRate.md) |  |  [optional]
**baseCurrency** | **kotlin.String** | Waluta oryginalna transakcji, kod ISO / Currency of the transaction, ISO code |  [optional]
**amountBaseCurrency** | **kotlin.String** | Kwota w oryginalnej walucie / Amount of the transaction |  [optional]
**usedPaymentInstrumentId** | **kotlin.String** | Unikalny identyfikator instrumentu płatniczego, za którego pomocą wykonano transakcję / Payment Instrument ID |  [optional]
**tppTransactionId** | **kotlin.String** | Unikalny identyfikator transakcji po stronie TPP / Transaction ID (TPP) |  [optional]
**tppName** | **kotlin.String** | Nazwa TPP / TPP name |  [optional]
**rejectionReason** | **kotlin.String** | Przyczyna odrzucenia / Reason for rejection |  [optional]
**holdExpirationDate** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) | Data ważności blokady, YYYY-MM-DDThh:mm:ss[.mmm] / Hold expiration date |  [optional]
**splitPayment** | **kotlin.Boolean** | Czy płatność jest podzielona (true / false) / Indicates if payment is split (true / false) |  [optional]
**transactionInfoSp** | [**TransactionInfoSp**](TransactionInfoSp.md) |  |  [optional]



