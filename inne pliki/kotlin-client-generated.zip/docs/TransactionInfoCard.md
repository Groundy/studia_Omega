
# TransactionInfoCard

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cardHolder** | **kotlin.String** | Właściciel karty / Card holder |  [optional]
**cardNumber** | **kotlin.String** | Numer karty / Card number |  [optional]



