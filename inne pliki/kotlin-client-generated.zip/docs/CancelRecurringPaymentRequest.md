
# CancelRecurringPaymentRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requestHeader** | [**RequestHeader**](RequestHeader.md) |  | 
**recurringPaymentId** | **kotlin.String** | Identyfikator płatności cyklicznej nadany przez ASPSP / Recurring payment identifier set by ASPSP | 



