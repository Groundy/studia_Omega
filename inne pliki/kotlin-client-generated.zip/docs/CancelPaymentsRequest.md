
# CancelPaymentsRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requestHeader** | [**RequestHeader**](RequestHeader.md) |  | 
**paymentId** | **kotlin.String** | Identyfikator płatności / Payment ID |  [optional]
**bundleId** | **kotlin.String** | Identyfikator paczki przelewów / Bundle of payments ID |  [optional]



