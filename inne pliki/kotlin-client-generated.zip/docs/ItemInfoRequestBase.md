
# ItemInfoRequestBase

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requestHeader** | [**RequestHeaderAISCallback**](RequestHeaderAISCallback.md) |  |  [optional]
**accountNumber** | **kotlin.String** | Numer rachunku / Account number |  [optional]
**itemIdFrom** | **kotlin.String** | Element filtru: elementy od podanego identyfikatora (transakcji lub blokady) / Filter element - id of transaction or hold to start from |  [optional]
**transactionDateFrom** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) | Element filtru: data transakcji od, YYYY-MM-DD / Filter element |  [optional]
**transactionDateTo** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) | Element filtru: data transakcji do, YYYY-MM-DD / Filter element |  [optional]
**bookingDateFrom** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) | Element filtru: data księgowania od, YYYY-MM-DD. Ignorowane w przypadku pobierania listy blokad. / Filter element. Ignored during list of holds retrieval. |  [optional]
**bookingDateTo** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) | Element filtru: data księgowania do, YYYY-MM-DD. Ignorowane w przypadku pobierania listy blokad. / Filter element. Ignored during list of holds retrieval. |  [optional]
**minAmount** | **kotlin.String** | Element filtru: kwota od / Filter element |  [optional]
**maxAmount** | **kotlin.String** | Element filtru: kwota do / Filter element |  [optional]
**pageId** | **kotlin.String** | Używane w celu stronicowania danych: identyfikator strony, która ma zostać zwrócona w odpowiedzi / Used for paging the results. Identifier of the page to be returned in the response. |  [optional]
**perPage** | **kotlin.Int** | Używane w celu stronicowania danych: wielkość strony danych / Page size (paging info) |  [optional]



