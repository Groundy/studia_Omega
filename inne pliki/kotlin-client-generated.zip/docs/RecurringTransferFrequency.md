
# RecurringTransferFrequency

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**periodType** | [**inline**](#PeriodTypeEnum) | Typ jednostki okresu czasu / The type of unit of time period | 
**periodValue** | **kotlin.Int** | Wartość jednostki okresu czasu / The value of unit of time period | 


<a name="PeriodTypeEnum"></a>
## Enum: periodType
Name | Value
---- | -----
periodType | day, week, month



