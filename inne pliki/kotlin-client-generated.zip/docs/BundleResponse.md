
# BundleResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**responseHeader** | [**ResponseHeader**](ResponseHeader.md) |  | 
**bundleId** | **kotlin.String** | Identyfikator paczki przelewów / Bundle of payments identifier |  [optional]
**bundleStatus** | [**inline**](#BundleStatusEnum) | Status paczki przelewów / Bundle of payments status |  [optional]
**bundleDetailedStatus** | **kotlin.String** | Szczegółowy status paczki przelewów / Bundle of payments detailed status |  [optional]
**payments** | [**kotlin.Array&lt;PaymentInfo&gt;**](PaymentInfo.md) |  |  [optional]


<a name="BundleStatusEnum"></a>
## Enum: bundleStatus
Name | Value
---- | -----
bundleStatus | inProgress, cancelled, done, partiallyDone



