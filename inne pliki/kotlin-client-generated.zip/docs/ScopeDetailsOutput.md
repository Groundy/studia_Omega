
# ScopeDetailsOutput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**privilegeList** | [**kotlin.Array&lt;ScopeDetailsOutputPrivilegeList&gt;**](ScopeDetailsOutputPrivilegeList.md) | The list of structures describing details of consent obtained by TPP. |  [optional]
**consentId** | **kotlin.String** | Identyfikator zgody / Id of consent | 
**scopeTimeLimit** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) | Data ważności zgody / consent valid until, YYYY-MM-DDThh:mm:ss[.mmm] | 
**throttlingPolicy** | [**inline**](#ThrottlingPolicyEnum) | Polityka przepustowości / Throttling policy | 


<a name="ThrottlingPolicyEnum"></a>
## Enum: throttlingPolicy
Name | Value
---- | -----
throttlingPolicy | psd2Regulatory



