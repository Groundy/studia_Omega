
# RecipientPIS

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountNumber** | [**AccountNumber**](AccountNumber.md) |  | 
**nameAddress** | [**NameAddress**](NameAddress.md) |  | 



