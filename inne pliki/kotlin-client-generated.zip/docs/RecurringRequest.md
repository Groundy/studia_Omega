
# RecurringRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requestHeader** | [**RequestHeaderCallback**](RequestHeaderCallback.md) |  | 
**tppRecurringPaymentId** | **kotlin.String** | Identyfikator płatności cyklicznej nadany przez TPP / Recurring payment identifier set by TPP | 
**recurrence** | [**RecurringTransferParameters**](RecurringTransferParameters.md) |  | 
**typeOfPayment** | [**inline**](#TypeOfPaymentEnum) | Typ przelewu, który zostanie wykorzystany do zdefiniowania nowej płatności cyklicznej  / The type of payment that is to be used to define new recurring payment | 
**domesticPayment** | [**RecurringDomesticPayment**](RecurringDomesticPayment.md) |  |  [optional]
**EEAPayment** | [**RecurringEEAPayment**](RecurringEEAPayment.md) |  |  [optional]
**nonEEAPayment** | [**RecurringNonEEAPayment**](RecurringNonEEAPayment.md) |  |  [optional]
**taxPayment** | [**RecurringTaxPayment**](RecurringTaxPayment.md) |  |  [optional]


<a name="TypeOfPaymentEnum"></a>
## Enum: typeOfPayment
Name | Value
---- | -----
typeOfPayment | domestic, EEA, nonEEA, tax



