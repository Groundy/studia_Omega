
# Bank

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bicOrSwift** | **kotlin.String** | Numer BIC/SWIFT Banku / BIC/SWIFT number |  [optional]
**name** | **kotlin.String** | Nazwa Banku / Bank&#39;s name |  [optional]
**code** | **kotlin.String** | Kod Banku, dla przelewów zagranicznych / Bank&#39;s code |  [optional]
**countryCode** | **kotlin.String** | Kod kraju 3166-1 / Country code |  [optional]
**address** | [**NameAddress**](NameAddress.md) |  |  [optional]



