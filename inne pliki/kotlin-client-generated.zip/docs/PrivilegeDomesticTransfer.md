
# PrivilegeDomesticTransfer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**scopeUsageLimit** | [**inline**](#ScopeUsageLimitEnum) | Rodzaj limitu zgody / Type of limit of usages |  [optional]
**recipient** | [**RecipientPIS**](RecipientPIS.md) |  |  [optional]
**sender** | [**SenderPIS**](SenderPIS.md) |  |  [optional]
**transferData** | [**TransferData**](TransferData.md) |  |  [optional]
**deliveryMode** | [**inline**](#DeliveryModeEnum) | Tryb pilności / Urgency mode |  [optional]
**system** | [**inline**](#SystemEnum) | Droga jaką przelew ma być rozliczony / The way the transfer should be settled |  [optional]
**hold** | **kotlin.Boolean** | Czy założyć blokadę (w przypadku np. zlecenia przelewu w dniu wolnym) / Indicates if payment should be held |  [optional]
**executionMode** | [**inline**](#ExecutionModeEnum) | Tryb realizacji płatności. Nadrzędna informacja decydująca o tym w jakim trybie zostanie zrealizowana płatność. / Payment execution mode. The superior information deciding which mode is to be used to execute payment. |  [optional]
**splitPayment** | **kotlin.Boolean** | Czy płatność jest podzielona (true / false) / Indicates if payment is split (true / false) |  [optional]
**transactionInfoSp** | [**TransactionInfoSp**](TransactionInfoSp.md) |  |  [optional]


<a name="ScopeUsageLimitEnum"></a>
## Enum: scopeUsageLimit
Name | Value
---- | -----
scopeUsageLimit | single, multiple


<a name="DeliveryModeEnum"></a>
## Enum: deliveryMode
Name | Value
---- | -----
deliveryMode | ExpressD0, StandardD1


<a name="SystemEnum"></a>
## Enum: system
Name | Value
---- | -----
system | Elixir, ExpressElixir, Sorbnet, BlueCash, Internal


<a name="ExecutionModeEnum"></a>
## Enum: executionMode
Name | Value
---- | -----
executionMode | Immediate, FutureDated



