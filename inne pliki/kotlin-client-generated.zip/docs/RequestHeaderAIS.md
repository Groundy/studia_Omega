
# RequestHeaderAIS

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**isDirectPsu** | **kotlin.Boolean** | (true/false) Znacznik informujący czy request jest przesłany bezpośrednio przez PSU. Domyślna wartość to false. / Is request sent by PSU directly. false is default value. |  [optional]



