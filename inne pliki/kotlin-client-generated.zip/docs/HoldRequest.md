
# HoldRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | [**inline**](#TypeEnum) | Element filtru: transakcji / Filter element |  [optional]


<a name="TypeEnum"></a>
## Enum: type
Name | Value
---- | -----
type | DEBIT



