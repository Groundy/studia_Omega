
# TransactionsScheduledInfoResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**responseHeader** | [**ResponseHeader**](ResponseHeader.md) |  | 
**transactions** | [**kotlin.Array&lt;TransactionScheduledInfo&gt;**](TransactionScheduledInfo.md) |  |  [optional]
**pageInfo** | [**PageInfo**](PageInfo.md) |  |  [optional]



