# CAFApi

All URIs are relative to *https://apiHost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getConfirmationOfFunds**](CAFApi.md#getConfirmationOfFunds) | **POST** /v3_0.1/confirmation/v3_0.1/getConfirmationOfFunds | Potwierdzenie dostępności środków na rachunku / Confirmation of the availability of funds


<a name="getConfirmationOfFunds"></a>
# **getConfirmationOfFunds**
> ConfirmationOfFundsResponse getConfirmationOfFunds(acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, confirmationOfFundsRequest)

Potwierdzenie dostępności środków na rachunku / Confirmation of the availability of funds

Potwierdzenie dostępności na rachunku płatnika kwoty niezbędnej do wykonania transakcji płatniczej, o której mowa w Art. 62 PSD2. / Confirming the availability on the payers account of the amount necessary to execute the payment transaction, as defined in Art. 65 PSD2.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = CAFApi()
val acceptEncoding : kotlin.String = acceptEncoding_example // kotlin.String | Gzip, deflate
val acceptLanguage : kotlin.String = acceptLanguage_example // kotlin.String | Preferowany język odpowiedzi / Prefered language of response
val acceptCharset : kotlin.String = acceptCharset_example // kotlin.String | UTF-8
val xJWSSIGNATURE : kotlin.String = xJWSSIGNATURE_example // kotlin.String | Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload
val xREQUESTID : kotlin.String = xREQUESTID_example // kotlin.String | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload.
val confirmationOfFundsRequest : ConfirmationOfFundsRequest =  // ConfirmationOfFundsRequest | Obiekt z kwotą do sprawdzenia / Object with amount to check
try {
    val result : ConfirmationOfFundsResponse = apiInstance.getConfirmationOfFunds(acceptEncoding, acceptLanguage, acceptCharset, xJWSSIGNATURE, xREQUESTID, confirmationOfFundsRequest)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CAFApi#getConfirmationOfFunds")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CAFApi#getConfirmationOfFunds")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **acceptEncoding** | **kotlin.String**| Gzip, deflate | [enum: gzip, deflate]
 **acceptLanguage** | **kotlin.String**| Preferowany język odpowiedzi / Prefered language of response |
 **acceptCharset** | **kotlin.String**| UTF-8 | [enum: utf-8]
 **xJWSSIGNATURE** | **kotlin.String**| Osobny podpis JWS treści paylodu / Detached JWS signature of the body of the payload |
 **xREQUESTID** | **kotlin.String**| Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1), zgodnym ze standardem RFC 4122, nadawany przez TPP. Wartość musi być zgodna z parametrem requestId przekazywanym w ciele każdego żądania. / Request identifier using UUID format (Variant 1, Version 1), described in RFC 4122 standard, set by TPP. Value of this header must be the same as for the requestId param passed inside request payload. |
 **confirmationOfFundsRequest** | [**ConfirmationOfFundsRequest**](ConfirmationOfFundsRequest.md)| Obiekt z kwotą do sprawdzenia / Object with amount to check |

### Return type

[**ConfirmationOfFundsResponse**](ConfirmationOfFundsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

