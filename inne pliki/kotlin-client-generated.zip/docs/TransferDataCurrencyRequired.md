
# TransferDataCurrencyRequired

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currency** | **kotlin.String** | Waluta / Currency | 



