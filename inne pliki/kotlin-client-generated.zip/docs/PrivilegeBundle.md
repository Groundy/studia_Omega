
# PrivilegeBundle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**scopeUsageLimit** | [**inline**](#ScopeUsageLimitEnum) | Rodzaj limitu zgody / Type of limit of usages |  [optional]
**bundleId** | **kotlin.String** | Identyfikator paczki płatności / Bundle of payments ID |  [optional]
**tppBundleId** | **kotlin.String** | Identyfikator paczki przelewów nadany przez TPP. / Bundle of payments identifier set by TPP. |  [optional]


<a name="ScopeUsageLimitEnum"></a>
## Enum: scopeUsageLimit
Name | Value
---- | -----
scopeUsageLimit | single, multiple



