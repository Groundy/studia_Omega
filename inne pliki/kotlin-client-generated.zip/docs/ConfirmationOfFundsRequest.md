
# ConfirmationOfFundsRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requestHeader** | [**RequestHeaderWithoutToken**](RequestHeaderWithoutToken.md) |  | 
**accountNumber** | **kotlin.String** | Numer konta / Account number | 
**amount** | **kotlin.String** | Wielkość środków której dotyczy zaptanie / Amount of the transaction | 
**currency** | **kotlin.String** | Kod ISO Waluty (waluta transakcji) / Currency of transaction (ISO) | 



