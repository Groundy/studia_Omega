
# PageInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**previousPage** | **kotlin.String** | Użyte w celu stronicowania danych: Identyfikator poprzedniej strony rezultatów / Used for paging the results. Identifier of the previous page. |  [optional]
**nextPage** | **kotlin.String** | Użyte w celu stronicowania danych:  Identyfikator następnej strony rezultatów / Used for paging the results. Identifier of the next page. |  [optional]



