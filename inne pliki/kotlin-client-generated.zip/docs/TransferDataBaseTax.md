
# TransferDataBaseTax

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **kotlin.String** | Kwota przelewu / Amount | 
**executionDate** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) | Data wykonania przelewu. Wymagany pod warunkiem przekazania wartości FutureDated w atrybucie executionMode. Format: YYYY-MM-DD / Date when the transfer is to be executed (YYYY-MM-DD). Required conditionally if executionMode attribute has value FutureDated. |  [optional]



