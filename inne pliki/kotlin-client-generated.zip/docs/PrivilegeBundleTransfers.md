
# PrivilegeBundleTransfers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**scopeUsageLimit** | [**inline**](#ScopeUsageLimitEnum) | Rodzaj limitu zgody / Type of limit of usages |  [optional]
**transfersTotalAmount** | **kotlin.String** | Łączna kwota wszystkich przelewów z paczki / The total amount of all transfers from bundle |  [optional]
**typeOfTransfers** | [**inline**](#TypeOfTransfersEnum) | Typ przelewów, które zostaną zlecone w ramach paczki / The type of transfers that will be initiated through the bundle |  [optional]
**domesticTransfers** | [**kotlin.Array&lt;PaymentDomesticRequestBundled&gt;**](PaymentDomesticRequestBundled.md) | Lista struktur danych przelewów zwykłych, które zostaną zlecone. Wymagane gdy typeOfTransfers &#x3D; domestic. / The list of data structures of domestic transfers to be initiated. Required when typeOfTransfers &#x3D; domestic. |  [optional]
**EEATransfers** | [**kotlin.Array&lt;PaymentEEARequestBundled&gt;**](PaymentEEARequestBundled.md) | Lista struktur danych przelewów zagranicznych SEPA, które zostaną zlecone. Wymagane gdy typeOfTransfers &#x3D; EEA. / The list of data structures of SEPA foreign transfers to be initiated. Required when typeOfTransfers &#x3D; EEA. |  [optional]
**nonEEATransfers** | [**kotlin.Array&lt;PaymentNonEEARequestBundled&gt;**](PaymentNonEEARequestBundled.md) | Lista struktur danych przelewów zagranicznych innych niż SEPA, które zostaną zlecone. Wymagane gdy typeOfTransfers &#x3D; nonEEA. / The list of data structures of non SEPA foreign transfers to be initiated. Required when typeOfTransfers &#x3D; nonEEA. |  [optional]
**taxTransfers** | [**kotlin.Array&lt;PaymentTaxRequestBundled&gt;**](PaymentTaxRequestBundled.md) | Lista struktur danych przelewów do urzędu podatkowego, które zostaną zlecone. Wymagane gdy typeOfTransfers &#x3D; tax. / The list of data structures of tax transfers to be initiated. Required when typeOfTransfers &#x3D; tax. |  [optional]


<a name="ScopeUsageLimitEnum"></a>
## Enum: scopeUsageLimit
Name | Value
---- | -----
scopeUsageLimit | single, multiple


<a name="TypeOfTransfersEnum"></a>
## Enum: typeOfTransfers
Name | Value
---- | -----
typeOfTransfers | domestic, EEA, nonEEA, tax



