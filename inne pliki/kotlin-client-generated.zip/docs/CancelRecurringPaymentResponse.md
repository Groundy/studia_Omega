
# CancelRecurringPaymentResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**responseHeader** | [**ResponseHeader**](ResponseHeader.md) |  | 
**recurringPaymentId** | **kotlin.String** | Identyfikator płatności cyklicznej nadany przez APSP / Recurring payment identifier set by ASPSP | 
**tppRecurringPaymentId** | **kotlin.String** | Identyfikator płatności cyklicznej nadany przez TPP. / Recurring payment identifier set by TPP. | 
**recurringPaymentStatus** | [**inline**](#RecurringPaymentStatusEnum) | Status płatności cyklicznej / Recurring payment status |  [optional]
**recurringPaymentDetailedStatus** | **kotlin.String** | Szczegółowy status płatności cyklicznej / Recurring payment detailed status |  [optional]


<a name="RecurringPaymentStatusEnum"></a>
## Enum: recurringPaymentStatus
Name | Value
---- | -----
recurringPaymentStatus | submitted, inProgress, cancelled, close



