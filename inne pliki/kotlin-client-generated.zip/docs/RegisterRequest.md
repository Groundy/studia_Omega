
# RegisterRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**software_statement** | **kotlin.String** |  | 



