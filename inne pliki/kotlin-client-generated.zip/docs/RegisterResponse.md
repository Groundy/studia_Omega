
# RegisterResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**responseHeader** | [**ResponseHeader**](ResponseHeader.md) |  | 
**client_id** | **kotlin.String** | Unikalny identyfikator aplikacji TPP / The unique identifier of the TTP application |  [optional]
**client_secret** | **kotlin.String** | Wartość tajna służąca uwierzytelnieniu aplikacji klienckiej względem serwera autoryzacji / A secret value used to authenticate the client application to the authorization server |  [optional]
**api_key** | **kotlin.String** | Wartość tajna służąca identyfikacji aplikacji klienckiej względem API / A secret value to identify the client application relative to the API |  [optional]
**jwks** | [**RegisterJWKS**](RegisterJWKS.md) |  |  [optional]
**jwks_uri** | **kotlin.String** | Kolekcja kluczy zawarta w URI (certyfikatów - dla kryptografii asymetrycznej), które mogą zostać użyte przez ASPSP dla podpisu odpowiedzi API. Zgodnie RFC 7591 i RFC 7517. Wymagane warunkowo o ile nie podano jwks. / A collection of keys contained in the URI (certificates - for asymmetric cryptography) that can be used by ASPSP for the signature of the API response. According to RFC 7591 and RFC 7517. Condition required unless jwks are given. |  [optional]



