
# Error

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**responseHeader** | [**ResponseHeader**](ResponseHeader.md) |  |  [optional]
**code** | **kotlin.String** | Kod błędu / Error code |  [optional]
**message** | **kotlin.String** | Opis błędu / Error message |  [optional]



