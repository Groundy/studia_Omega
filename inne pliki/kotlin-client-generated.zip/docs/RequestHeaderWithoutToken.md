
# RequestHeaderWithoutToken

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requestId** | [**java.util.UUID**](java.util.UUID.md) | Identyfikator żądania w formacie UUID (Wariant 1, Wersja 1) zgodnym ze standardem RFC 4122 / Request ID using UUID format (Variant 1, Version 1) described in RFC 4122 standard | 
**userAgent** | **kotlin.String** | Browser agent dla PSU / PSU browser agent |  [optional]
**ipAddress** | **kotlin.String** | Adres IP końcowego urządzenia PSU. Wymagany dla isDirectPsu&#x3D;true. / IP address of PSU&#39;s terminal device. Required when isDirectPsu&#x3D;true. |  [optional]
**sendDate** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) | Oryginalna data wysłania, format: YYYY-MM-DDThh:mm:ss[.mmm] / Send date |  [optional]
**tppId** | **kotlin.String** | Identyfikator TPP / TPP ID | 



