
# CurrencyRate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rate** | **kotlin.Double** | Kursy przewalutowania / Currency exchange rate |  [optional]
**fromCurrency** | **kotlin.String** | Waluta rachunku, kod ISO / from Currency, ISO code |  [optional]
**toCurrency** | **kotlin.String** | Waluta rachunku, kod ISO / to Currency, ISO code |  [optional]



