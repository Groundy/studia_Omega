
# ScopeDetailsInputPrivilegeList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountNumber** | [**AccountNumber**](AccountNumber.md) |  |  [optional]
**ais-accounts:getAccounts** | [**PrivilegeAisAspspInSimple**](PrivilegeAisAspspInSimple.md) |  |  [optional]
**ais:getAccount** | [**PrivilegeAisAspspInSimple**](PrivilegeAisAspspInSimple.md) |  |  [optional]
**ais:getHolds** | [**PrivilegeAisAspspIn**](PrivilegeAisAspspIn.md) |  |  [optional]
**ais:getTransactionsDone** | [**PrivilegeAisAspspIn**](PrivilegeAisAspspIn.md) |  |  [optional]
**ais:getTransactionsPending** | [**PrivilegeAisAspspIn**](PrivilegeAisAspspIn.md) |  |  [optional]
**ais:getTransactionsRejected** | [**PrivilegeAisAspspIn**](PrivilegeAisAspspIn.md) |  |  [optional]
**ais:getTransactionsCancelled** | [**PrivilegeAisAspspIn**](PrivilegeAisAspspIn.md) |  |  [optional]
**ais:getTransactionsScheduled** | [**PrivilegeAisAspspIn**](PrivilegeAisAspspIn.md) |  |  [optional]
**ais:getTransactionDetail** | [**PrivilegeAisAspspInSimple**](PrivilegeAisAspspInSimple.md) |  |  [optional]
**pis:getPayment** | [**PrivilegePayment**](PrivilegePayment.md) |  |  [optional]
**pis:getBundle** | [**PrivilegeBundle**](PrivilegeBundle.md) |  |  [optional]
**pis:domestic** | [**PrivilegeDomesticTransfer**](PrivilegeDomesticTransfer.md) |  |  [optional]
**pis:EEA** | [**PrivilegeForeignTransferEEA**](PrivilegeForeignTransferEEA.md) |  |  [optional]
**pis:nonEEA** | [**PrivilegeForeignTransferNonEEA**](PrivilegeForeignTransferNonEEA.md) |  |  [optional]
**pis:tax** | [**PrivilegeTaxTransfer**](PrivilegeTaxTransfer.md) |  |  [optional]
**pis:cancelPayment** | [**PrivilegeCancelPayment**](PrivilegeCancelPayment.md) |  |  [optional]
**pis:bundle** | [**PrivilegeBundleTransfers**](PrivilegeBundleTransfers.md) |  |  [optional]
**pis:recurring** | [**PrivilegeRecurringPayment**](PrivilegeRecurringPayment.md) |  |  [optional]
**pis:getRecurringPayment** | [**PrivilegeRecurringPaymentStatus**](PrivilegeRecurringPaymentStatus.md) |  |  [optional]
**pis:cancelRecurringPayment** | [**PrivilegeCancelRecurringPayment**](PrivilegeCancelRecurringPayment.md) |  |  [optional]



