
# ConfirmationOfFundsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**responseHeader** | [**ResponseHeader**](ResponseHeader.md) |  | 
**fundsAvailable** | **kotlin.Boolean** | Status - Czy środki są dostępne / Status - are funds available | 



