
# RecurringResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**responseHeader** | [**ResponseHeader**](ResponseHeader.md) |  | 
**recurringPaymentId** | **kotlin.String** | Identyfikator płatności cyklicznej nadany przez ASPSP / Recurring payment identifier set by ASPSP |  [optional]
**recurrence** | [**RecurringTransferParameters**](RecurringTransferParameters.md) |  |  [optional]
**recurringPaymentStatus** | [**inline**](#RecurringPaymentStatusEnum) | Status płatności cyklicznej / Status of recurring payment |  [optional]
**recurringPaymentDetailedStatus** | **kotlin.String** | Szczegółowy status płatności cyklicznej / Recurring payment detailed status |  [optional]


<a name="RecurringPaymentStatusEnum"></a>
## Enum: recurringPaymentStatus
Name | Value
---- | -----
recurringPaymentStatus | submitted, inProgress, cancelled, close



