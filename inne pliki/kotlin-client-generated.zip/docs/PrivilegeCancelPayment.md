
# PrivilegeCancelPayment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**scopeUsageLimit** | [**inline**](#ScopeUsageLimitEnum) | Rodzaj limitu zgody / Type of limit of usages |  [optional]
**paymentId** | **kotlin.String** | Identyfikator płatności / Payment ID |  [optional]
**bundleId** | **kotlin.String** | Identyfikator paczki przelewów / Bundle of payments ID |  [optional]


<a name="ScopeUsageLimitEnum"></a>
## Enum: scopeUsageLimit
Name | Value
---- | -----
scopeUsageLimit | single, multiple



