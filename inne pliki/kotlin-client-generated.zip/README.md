# io.swagger.client - Kotlin client library for Polish API

## Requires

* Kotlin 1.1.2
* Gradle 3.3

## Build

First, create the gradle wrapper script:

```
gradle wrapper
```

Then, run:

```
./gradlew check assemble
```

This runs all tests and packages the library.

## Features/Implementation Notes

* Supports JSON inputs/outputs, File inputs, and Form inputs.
* Supports collection formats for query parameters: csv, tsv, ssv, pipes.
* Some Kotlin and Java types are fully qualified to avoid conflicts with types defined in Swagger definitions.
* Implementation of ApiClient is intended to reduce method counts, specifically to benefit Android targets.

<a name="documentation-for-api-endpoints"></a>
## Documentation for API Endpoints

All URIs are relative to *https://apiHost*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*AISApi* | [**deleteConsent**](docs/AISApi.md#deleteconsent) | **POST** /v3_0.1/accounts/v3_0.1/deleteConsent | Usuwa zezwolenie / Removes consent
*AISApi* | [**getAccount**](docs/AISApi.md#getaccount) | **POST** /v3_0.1/accounts/v3_0.1/getAccount | Uzyskanie szczegółowych informacji o koncie płatniczym użytkownika / Get detailed information about user payment account
*AISApi* | [**getAccounts**](docs/AISApi.md#getaccounts) | **POST** /v3_0.1/accounts/v3_0.1/getAccounts | Uzyskanie informacji na temat wszystkich kont płatniczych użytkownika / Get information about all user's payment account
*AISApi* | [**getHolds**](docs/AISApi.md#getholds) | **POST** /v3_0.1/accounts/v3_0.1/getHolds | Pobranie informacji o blokadach na koncie użytkownika / Get list of user's held operations
*AISApi* | [**getTransactionDetail**](docs/AISApi.md#gettransactiondetail) | **POST** /v3_0.1/accounts/v3_0.1/getTransactionDetail | Pobranie szczegółowych informacji o pojedynczej transkacji użytkownika / Get detailed information about user's single transaction
*AISApi* | [**getTransactionsCancelled**](docs/AISApi.md#gettransactionscancelled) | **POST** /v3_0.1/accounts/v3_0.1/getTransactionsCancelled | Pobranie informacji o anulowanych transakcjach użytkownika / Get list of user cancelled transactions
*AISApi* | [**getTransactionsDone**](docs/AISApi.md#gettransactionsdone) | **POST** /v3_0.1/accounts/v3_0.1/getTransactionsDone | Pobranie informacji o zaksięgowanych transakcjach użytkownika / Get list of user done transactions
*AISApi* | [**getTransactionsPending**](docs/AISApi.md#gettransactionspending) | **POST** /v3_0.1/accounts/v3_0.1/getTransactionsPending | Pobranie informacji o oczekujących transakcjach użytkownika / Get list of user's pending transactions
*AISApi* | [**getTransactionsRejected**](docs/AISApi.md#gettransactionsrejected) | **POST** /v3_0.1/accounts/v3_0.1/getTransactionsRejected | Pobranie informacji o odrzuconych transakcjach użytkownika / Get list of user's rejected transactions
*AISApi* | [**getTransactionsScheduled**](docs/AISApi.md#gettransactionsscheduled) | **POST** /v3_0.1/accounts/v3_0.1/getTransactionsScheduled | Pobranie informacji o zaplanowanych transakcjach użytkownika / Get list of user scheduled transactions
*ASApi* | [**authorize**](docs/ASApi.md#authorize) | **POST** /v3_0.1/auth/v3_0.1/authorize | Żądanie kodu autoryzacji OAuth2 / Requests OAuth2 authorization code
*ASApi* | [**authorizeExt**](docs/ASApi.md#authorizeext) | **POST** /v3_0.1/auth/v3_0.1/authorizeExt | Żądanie wydania kodu autoryzacji OAuth2 na podstawie jednorazowego kodu autoryzacji wydanego przez narzędzie autoryzacji zewnętrznej / Requests OAuth2 authorization code based on One-time authorization code issued by External Authorization Tool
*ASApi* | [**register**](docs/ASApi.md#register) | **POST** /v3_0.1/auth/v3_0.1/register | Żądanie rejestracji aplikacji klienckiej / Client application registration request
*ASApi* | [**token**](docs/ASApi.md#token) | **POST** /v3_0.1/auth/v3_0.1/token | Żądanie wydania tokena dostępu OAuth2 / Requests OAuth2 access token value
*CAFApi* | [**getConfirmationOfFunds**](docs/CAFApi.md#getconfirmationoffunds) | **POST** /v3_0.1/confirmation/v3_0.1/getConfirmationOfFunds | Potwierdzenie dostępności środków na rachunku / Confirmation of the availability of funds
*PISApi* | [**bundle**](docs/PISApi.md#bundle) | **POST** /v3_0.1/payments/v3_0.1/bundle | Inicjacja wielu przelewów / Initiate many transfers as bundle
*PISApi* | [**cancelPayments**](docs/PISApi.md#cancelpayments) | **POST** /v3_0.1/payments/v3_0.1/cancelPayments | Anulowanie zaplanowanych płatności / Cancelation of future dated payment
*PISApi* | [**cancelRecurringPayment**](docs/PISApi.md#cancelrecurringpayment) | **POST** /v3_0.1/payments/v3_0.1/cancelRecurringPayment | Anulowanie płatności cyklicznej / Cancelation of recurring payment
*PISApi* | [**domestic**](docs/PISApi.md#domestic) | **POST** /v3_0.1/payments/v3_0.1/domestic | Inicjacja przelewu krajowego / Initiate domestic transfer
*PISApi* | [**eEA**](docs/PISApi.md#eea) | **POST** /v3_0.1/payments/v3_0.1/EEA | Inicjacja przelewów zagranicznych SEPA / Initiate SEPA foreign transfers
*PISApi* | [**getBundle**](docs/PISApi.md#getbundle) | **POST** /v3_0.1/payments/v3_0.1/getBundle | Uzyskanie status paczki przelewów / Get the status of bundle of payments
*PISApi* | [**getMultiplePayments**](docs/PISApi.md#getmultiplepayments) | **POST** /v3_0.1/payments/v3_0.1/getMultiplePayments | Uzyskanie statusu wielu płatności / Get the status of multiple payments
*PISApi* | [**getPayment**](docs/PISApi.md#getpayment) | **POST** /v3_0.1/payments/v3_0.1/getPayment | Uzyskanie statusu płatności / Get the status of payment
*PISApi* | [**getRecurringPayment**](docs/PISApi.md#getrecurringpayment) | **POST** /v3_0.1/payments/v3_0.1/getRecurringPayment | Uzyskanie status płatności cyklicznej / Get the status of recurring payment
*PISApi* | [**nonEEA**](docs/PISApi.md#noneea) | **POST** /v3_0.1/payments/v3_0.1/nonEEA | Inicjacja przelewów zagranicznych niezgodnych z SEPA / Initiate non SEPA foreign transfers
*PISApi* | [**recurring**](docs/PISApi.md#recurring) | **POST** /v3_0.1/payments/v3_0.1/recurring | Definicja nowej płatności cyklicznej / Defines new recurring payment
*PISApi* | [**tax**](docs/PISApi.md#tax) | **POST** /v3_0.1/payments/v3_0.1/tax | Inicjacja przelewu do organu podatkowego / Initiate tax transfer


<a name="documentation-for-models"></a>
## Documentation for Models

 - [io.swagger.client.models.AccountBaseInfo](docs/AccountBaseInfo.md)
 - [io.swagger.client.models.AccountInfo](docs/AccountInfo.md)
 - [io.swagger.client.models.AccountInfoRequest](docs/AccountInfoRequest.md)
 - [io.swagger.client.models.AccountNumber](docs/AccountNumber.md)
 - [io.swagger.client.models.AccountPsuRelation](docs/AccountPsuRelation.md)
 - [io.swagger.client.models.AccountResponse](docs/AccountResponse.md)
 - [io.swagger.client.models.AccountsRequest](docs/AccountsRequest.md)
 - [io.swagger.client.models.AccountsResponse](docs/AccountsResponse.md)
 - [io.swagger.client.models.AddPaymentResponse](docs/AddPaymentResponse.md)
 - [io.swagger.client.models.AuthorizeRequest](docs/AuthorizeRequest.md)
 - [io.swagger.client.models.AuthorizeResponse](docs/AuthorizeResponse.md)
 - [io.swagger.client.models.Bank](docs/Bank.md)
 - [io.swagger.client.models.BankAccountInfo](docs/BankAccountInfo.md)
 - [io.swagger.client.models.BundleRequest](docs/BundleRequest.md)
 - [io.swagger.client.models.BundleResponse](docs/BundleResponse.md)
 - [io.swagger.client.models.CancelPaymentsRequest](docs/CancelPaymentsRequest.md)
 - [io.swagger.client.models.CancelPaymentsResponse](docs/CancelPaymentsResponse.md)
 - [io.swagger.client.models.CancelRecurringPaymentRequest](docs/CancelRecurringPaymentRequest.md)
 - [io.swagger.client.models.CancelRecurringPaymentResponse](docs/CancelRecurringPaymentResponse.md)
 - [io.swagger.client.models.ConfirmationOfFundsRequest](docs/ConfirmationOfFundsRequest.md)
 - [io.swagger.client.models.ConfirmationOfFundsResponse](docs/ConfirmationOfFundsResponse.md)
 - [io.swagger.client.models.CurrencyRate](docs/CurrencyRate.md)
 - [io.swagger.client.models.DeleteConsentRequest](docs/DeleteConsentRequest.md)
 - [io.swagger.client.models.DictionaryItem](docs/DictionaryItem.md)
 - [io.swagger.client.models.DomesticRequest](docs/DomesticRequest.md)
 - [io.swagger.client.models.EEARequest](docs/EEARequest.md)
 - [io.swagger.client.models.EatCodeRequest](docs/EatCodeRequest.md)
 - [io.swagger.client.models.Error](docs/Error.md)
 - [io.swagger.client.models.GetBundleRequest](docs/GetBundleRequest.md)
 - [io.swagger.client.models.GetBundleResponse](docs/GetBundleResponse.md)
 - [io.swagger.client.models.GetMultiplePaymentsRequest](docs/GetMultiplePaymentsRequest.md)
 - [io.swagger.client.models.GetMultiplePaymentsResponse](docs/GetMultiplePaymentsResponse.md)
 - [io.swagger.client.models.GetPaymentRequest](docs/GetPaymentRequest.md)
 - [io.swagger.client.models.GetPaymentResponse](docs/GetPaymentResponse.md)
 - [io.swagger.client.models.GetRecurringPaymentRequest](docs/GetRecurringPaymentRequest.md)
 - [io.swagger.client.models.GetRecurringPaymentResponse](docs/GetRecurringPaymentResponse.md)
 - [io.swagger.client.models.HoldInfo](docs/HoldInfo.md)
 - [io.swagger.client.models.HoldInfoResponse](docs/HoldInfoResponse.md)
 - [io.swagger.client.models.HoldRequest](docs/HoldRequest.md)
 - [io.swagger.client.models.ItemInfoBase](docs/ItemInfoBase.md)
 - [io.swagger.client.models.ItemInfoRequestBase](docs/ItemInfoRequestBase.md)
 - [io.swagger.client.models.Map](docs/Map.md)
 - [io.swagger.client.models.NameAddress](docs/NameAddress.md)
 - [io.swagger.client.models.NonEEARequest](docs/NonEEARequest.md)
 - [io.swagger.client.models.PageInfo](docs/PageInfo.md)
 - [io.swagger.client.models.PaymentDomesticRequestBundled](docs/PaymentDomesticRequestBundled.md)
 - [io.swagger.client.models.PaymentEEARequestBundled](docs/PaymentEEARequestBundled.md)
 - [io.swagger.client.models.PaymentInfo](docs/PaymentInfo.md)
 - [io.swagger.client.models.PaymentNonEEARequestBundled](docs/PaymentNonEEARequestBundled.md)
 - [io.swagger.client.models.PaymentStatus](docs/PaymentStatus.md)
 - [io.swagger.client.models.PaymentTaxRequestBundled](docs/PaymentTaxRequestBundled.md)
 - [io.swagger.client.models.PaymentTokenEntry](docs/PaymentTokenEntry.md)
 - [io.swagger.client.models.Payor](docs/Payor.md)
 - [io.swagger.client.models.PrivilegeAisAspspIn](docs/PrivilegeAisAspspIn.md)
 - [io.swagger.client.models.PrivilegeAisAspspInSimple](docs/PrivilegeAisAspspInSimple.md)
 - [io.swagger.client.models.PrivilegeAisAspspOut](docs/PrivilegeAisAspspOut.md)
 - [io.swagger.client.models.PrivilegeAisAspspOutSimple](docs/PrivilegeAisAspspOutSimple.md)
 - [io.swagger.client.models.PrivilegeBundle](docs/PrivilegeBundle.md)
 - [io.swagger.client.models.PrivilegeBundleTransfers](docs/PrivilegeBundleTransfers.md)
 - [io.swagger.client.models.PrivilegeCancelPayment](docs/PrivilegeCancelPayment.md)
 - [io.swagger.client.models.PrivilegeCancelRecurringPayment](docs/PrivilegeCancelRecurringPayment.md)
 - [io.swagger.client.models.PrivilegeDomesticTransfer](docs/PrivilegeDomesticTransfer.md)
 - [io.swagger.client.models.PrivilegeForeignTransferEEA](docs/PrivilegeForeignTransferEEA.md)
 - [io.swagger.client.models.PrivilegeForeignTransferNonEEA](docs/PrivilegeForeignTransferNonEEA.md)
 - [io.swagger.client.models.PrivilegePayment](docs/PrivilegePayment.md)
 - [io.swagger.client.models.PrivilegeRecurringPayment](docs/PrivilegeRecurringPayment.md)
 - [io.swagger.client.models.PrivilegeRecurringPaymentStatus](docs/PrivilegeRecurringPaymentStatus.md)
 - [io.swagger.client.models.PrivilegeTaxTransfer](docs/PrivilegeTaxTransfer.md)
 - [io.swagger.client.models.RecipientPIS](docs/RecipientPIS.md)
 - [io.swagger.client.models.RecipientPISForeign](docs/RecipientPISForeign.md)
 - [io.swagger.client.models.RecurringDomesticPayment](docs/RecurringDomesticPayment.md)
 - [io.swagger.client.models.RecurringEEAPayment](docs/RecurringEEAPayment.md)
 - [io.swagger.client.models.RecurringNonEEAPayment](docs/RecurringNonEEAPayment.md)
 - [io.swagger.client.models.RecurringRequest](docs/RecurringRequest.md)
 - [io.swagger.client.models.RecurringResponse](docs/RecurringResponse.md)
 - [io.swagger.client.models.RecurringTaxPayment](docs/RecurringTaxPayment.md)
 - [io.swagger.client.models.RecurringTransferFrequency](docs/RecurringTransferFrequency.md)
 - [io.swagger.client.models.RecurringTransferParameters](docs/RecurringTransferParameters.md)
 - [io.swagger.client.models.RegisterJWKS](docs/RegisterJWKS.md)
 - [io.swagger.client.models.RegisterJWKSKeys](docs/RegisterJWKSKeys.md)
 - [io.swagger.client.models.RegisterRequest](docs/RegisterRequest.md)
 - [io.swagger.client.models.RegisterResponse](docs/RegisterResponse.md)
 - [io.swagger.client.models.RequestHeader](docs/RequestHeader.md)
 - [io.swagger.client.models.RequestHeaderAIS](docs/RequestHeaderAIS.md)
 - [io.swagger.client.models.RequestHeaderAISCallback](docs/RequestHeaderAISCallback.md)
 - [io.swagger.client.models.RequestHeaderCallback](docs/RequestHeaderCallback.md)
 - [io.swagger.client.models.RequestHeaderToken](docs/RequestHeaderToken.md)
 - [io.swagger.client.models.RequestHeaderWithoutToken](docs/RequestHeaderWithoutToken.md)
 - [io.swagger.client.models.RequestHeaderWithoutTokenAS](docs/RequestHeaderWithoutTokenAS.md)
 - [io.swagger.client.models.RequestHeaderWithoutTokenCallbackAS](docs/RequestHeaderWithoutTokenCallbackAS.md)
 - [io.swagger.client.models.ResponseHeader](docs/ResponseHeader.md)
 - [io.swagger.client.models.ScopeDetailsInput](docs/ScopeDetailsInput.md)
 - [io.swagger.client.models.ScopeDetailsInputPrivilegeList](docs/ScopeDetailsInputPrivilegeList.md)
 - [io.swagger.client.models.ScopeDetailsOutput](docs/ScopeDetailsOutput.md)
 - [io.swagger.client.models.ScopeDetailsOutputPrivilegeList](docs/ScopeDetailsOutputPrivilegeList.md)
 - [io.swagger.client.models.SenderPIS](docs/SenderPIS.md)
 - [io.swagger.client.models.SenderRecipient](docs/SenderRecipient.md)
 - [io.swagger.client.models.SocialSecurityPayor](docs/SocialSecurityPayor.md)
 - [io.swagger.client.models.TaxRequest](docs/TaxRequest.md)
 - [io.swagger.client.models.TokenRequest](docs/TokenRequest.md)
 - [io.swagger.client.models.TokenResponse](docs/TokenResponse.md)
 - [io.swagger.client.models.TransactionCancelledInfo](docs/TransactionCancelledInfo.md)
 - [io.swagger.client.models.TransactionDetailRequest](docs/TransactionDetailRequest.md)
 - [io.swagger.client.models.TransactionDetailResponse](docs/TransactionDetailResponse.md)
 - [io.swagger.client.models.TransactionInfo](docs/TransactionInfo.md)
 - [io.swagger.client.models.TransactionInfoCard](docs/TransactionInfoCard.md)
 - [io.swagger.client.models.TransactionInfoRequest](docs/TransactionInfoRequest.md)
 - [io.swagger.client.models.TransactionInfoSp](docs/TransactionInfoSp.md)
 - [io.swagger.client.models.TransactionInfoTax](docs/TransactionInfoTax.md)
 - [io.swagger.client.models.TransactionInfoZUS](docs/TransactionInfoZUS.md)
 - [io.swagger.client.models.TransactionPendingInfo](docs/TransactionPendingInfo.md)
 - [io.swagger.client.models.TransactionPendingInfoResponse](docs/TransactionPendingInfoResponse.md)
 - [io.swagger.client.models.TransactionRejectedInfo](docs/TransactionRejectedInfo.md)
 - [io.swagger.client.models.TransactionRejectedInfoResponse](docs/TransactionRejectedInfoResponse.md)
 - [io.swagger.client.models.TransactionScheduledInfo](docs/TransactionScheduledInfo.md)
 - [io.swagger.client.models.TransactionsCancelledInfoResponse](docs/TransactionsCancelledInfoResponse.md)
 - [io.swagger.client.models.TransactionsDoneInfoResponse](docs/TransactionsDoneInfoResponse.md)
 - [io.swagger.client.models.TransactionsScheduledInfoResponse](docs/TransactionsScheduledInfoResponse.md)
 - [io.swagger.client.models.TransferData](docs/TransferData.md)
 - [io.swagger.client.models.TransferDataBase](docs/TransferDataBase.md)
 - [io.swagger.client.models.TransferDataBaseTax](docs/TransferDataBaseTax.md)
 - [io.swagger.client.models.TransferDataCurrencyRequired](docs/TransferDataCurrencyRequired.md)
 - [io.swagger.client.models.TransferDataCurrencyRequiredTax](docs/TransferDataCurrencyRequiredTax.md)


<a name="documentation-for-authorization"></a>
## Documentation for Authorization

<a name="xs2a_auth_aspsp"></a>
### xs2a_auth_aspsp

- **Type**: OAuth
- **Flow**: accessCode
- **Authorization URL**: https://apiHost/v3_0.1/auth/v3_0.1/authorize
- **Scopes**: 
  - ais-accounts: Zgoda na pobranie listy rachunków za pośrednictwem usługi informacji o koncie / Permission to retrieve the list of accounts through Account Information Service
  - ais: Zgoda na wykorzystanie metod usługi informacji o koncie w kontekście danego rachunku / Permission to execute methods of Account Information Service in context of particular account
  - pis: Zgoda na inicjowanie płatności i sprawdzanie ich statusu poprzez usługę inicjowania płatności / Permission to initiate payments and check their statuses through Payment Initiation Service

<a name="xs2a_auth_decoupled"></a>
### xs2a_auth_decoupled

- **Type**: OAuth
- **Flow**: accessCode
- **Authorization URL**: https://apiHost/auth/authorizeExt
- **Scopes**: 
  - ais-accounts: Zgoda na pobranie listy rachunków za pośrednictwem usługi informacji o koncie / Permission to retrieve the list of accounts through Account Information Service
  - ais: Zgoda na wykorzystanie metod usługi informacji o koncie w kontekście danego konta / Permission to execute methods of Account Information Service in context of particular account
  - pis: Zgoda na inicjowanie płatności i sprawdzanie ich statusu poprzez usługę inicjowania płatności / Permission to initiate payments and check their statuses through Payment Initiation Service

